/* One block per language. A missing word falls back to English. To add a language, copy the "en" block and translate it. */
window.PS_I18N = {
en: {
tag: "Pi community app", signin: "Pi Sign in", signin_title: "Sign in with Pi",
signin_note: "Test mode: type your Pi username. Real Pi sign-in works when the app is opened in Pi Browser.",
user_ph: "Pi username", cont: "Continue", skip: "Skip", sound: "Sound on",
p_title: "Complete your profile", p_sub: "Chats, meetings, feed and rewards open after you submit this form.",
photo: "Profile photo", upload: "Upload image", name: "Real name", mobile: "Mobile number", gmail: "Gmail",
country: "Country", state: "State", city: "City", vis: "Profile visibility", pub: "Public · earns SP", priv: "Private · no SP",
warn: "Wrong profile details mean you will not receive Sphere Points (SP). Fill in your real information.",
confirm: "I confirm these details are correct", submit: "Submit profile", save: "Save",
e_req: "Fill in every field and tick the box.", e_mail: "Enter a valid Gmail address.", e_mob: "Enter a valid mobile number.",
n_chats: "Chats", n_meet: "Meetings", n_feed: "Feed", n_rew: "Rewards",
t_chats: "Chats", t_groups: "Groups", t_channels: "Channels", new_chat: "New chat", new_group: "New group", new_channel: "New channel",
name_ph: "Name", create: "Create", cancel: "Cancel", close: "Close", summary: "AI chat summary", soon: "This connects in the next stage.",
msg_ph: "Write a message", send: "Send", members: "members", empty: "Nothing here yet", back: "Back",
ch_only: "Only the owner can post in a channel.",
m_title: "Cloud meetings", m_create: "Create meeting group", m_join: "Join live meeting", m_id: "Enter meeting ID", join: "Join", start: "Start",
m_yours: "Your meeting groups", m_rule: "Every 5 people in a meeting earn the host 1 SP.", m_id_lbl: "Meeting ID",
post_ph: "Write a post", post: "Post", like: "Like", dislike: "Dislike", share: "Share", tip: "Tip SP", pin: "Pin", unpin: "Unpin", del: "Delete", claim: "Claim",
like_rule: "100 likes earn the author 1 SP", sponsored: "Sponsored", ad: "LOCAL AD", pinned: "Pinned",
sp_title: "Sphere Points", sp_bal: "SP balance", hold: "Press and hold to send or receive", receive: "Receive",
buy: "Buy SP with Pi", buy_note: "Payment comes from your Pi Wallet. SP cannot be changed back to Pi and purchases are not refunded.",
watch: "Watch an ad, earn SP", hist: "SP history", no_hist: "No activity yet", settings: "Settings", edit: "Edit profile", admin: "Admin panel", lang: "Language",
tip_to: "Send tip to", amt: "SP amount", e_amt: "Enter an amount you have.", tip_ok: "Tip sent", recv_note: "Share your Pi username to receive SP:",
pubb: "PUBLIC", privb: "PRIVATE", priv_note: "This profile is private.", contact: "Contact number", email: "Email",
test_credit: "Test mode: SP added without payment.", copied: "Copied", copy: "Copy", claim_ph: "Why is this dislike wrong?", claim_ok: "Claim sent to admin",
h_buy: "Bought with Pi (test)", h_tip: "Tip sent to", h_reward: "Reward", h_send: "Sent to", lim_dis: "Daily dislike limit reached.",
hold_tip: "Tap a name to see the profile. Press and hold for more.",
a_rules: "Rules you can change", a_ads: "Post a local ad", a_title: "Ad title", a_text: "Ad text", a_link: "Link or phone number", a_city: "City (blank = everyone)",
a_from: "From", a_to: "To", a_places: "Where to show", a_ticker: "Header ticker", a_feed: "Post feed", a_chats: "Chat rooms", a_meet: "Meetings",
a_post: "Post ad", a_live: "Running ads", a_claims: "Dislike claims", a_ok: "Approve", a_no: "Reject", a_reset: "Reset test data",
a_reset_q: "This clears chats, posts, SP and ads on this device. Your profile stays.", a_yes: "Yes, reset", a_colors: "Ticker colours", a_bg: "Background", a_fg: "Text", a_saved: "Saved",
a_note: "Stage 1 stores data on this device only. Shared data and real checks come with the server in stage 2."
},
hi: {
tag: "Pi कम्युनिटी ऐप", signin: "Pi साइन इन", signin_title: "Pi से साइन इन करें",
signin_note: "टेस्ट मोड: अपना Pi यूजरनेम लिखें। असली Pi साइन-इन Pi Browser में ऐप खोलने पर चलेगा।",
user_ph: "Pi यूजरनेम", cont: "आगे बढ़ें", skip: "छोड़ें", sound: "आवाज चालू",
p_title: "अपनी प्रोफाइल पूरी करें", p_sub: "यह फॉर्म भरने के बाद ही चैट, मीटिंग, फीड और रिवॉर्ड खुलेंगे।",
photo: "प्रोफाइल फोटो", upload: "फोटो अपलोड करें", name: "असली नाम", mobile: "मोबाइल नंबर", gmail: "जीमेल",
country: "देश", state: "राज्य", city: "शहर", vis: "प्रोफाइल किसे दिखे", pub: "पब्लिक · SP मिलेगा", priv: "प्राइवेट · SP नहीं",
warn: "गलत प्रोफाइल जानकारी भरने पर आपको स्फीयर पॉइंट (SP) नहीं मिलेंगे। अपनी असली जानकारी भरें।",
confirm: "मैं पुष्टि करता हूँ कि यह जानकारी सही है", submit: "प्रोफाइल जमा करें", save: "सेव करें",
e_req: "सारे कॉलम भरें और बॉक्स पर टिक करें।", e_mail: "सही जीमेल पता लिखें।", e_mob: "सही मोबाइल नंबर लिखें।",
n_chats: "चैट", n_meet: "मीटिंग", n_feed: "फीड", n_rew: "रिवॉर्ड",
t_chats: "चैट", t_groups: "ग्रुप", t_channels: "चैनल", new_chat: "नई चैट", new_group: "नया ग्रुप", new_channel: "नया चैनल",
name_ph: "नाम", create: "बनाएं", cancel: "रद्द करें", close: "बंद करें", summary: "AI चैट समरी", soon: "यह अगले चरण में जुड़ेगा।",
msg_ph: "मैसेज लिखें", send: "भेजें", members: "मेंबर", empty: "अभी यहाँ कुछ नहीं है", back: "वापस",
ch_only: "चैनल में सिर्फ मालिक पोस्ट कर सकता है।",
m_title: "क्लाउड मीटिंग", m_create: "मीटिंग ग्रुप बनाएं", m_join: "लाइव मीटिंग जॉइन करें", m_id: "मीटिंग आईडी लिखें", join: "जॉइन", start: "शुरू करें",
m_yours: "आपके मीटिंग ग्रुप", m_rule: "मीटिंग में हर 5 लोगों पर होस्ट को 1 SP मिलता है।", m_id_lbl: "मीटिंग आईडी",
post_ph: "पोस्ट लिखें", post: "पोस्ट", like: "लाइक", dislike: "डिसलाइक", share: "शेयर", tip: "SP टिप", pin: "पिन", unpin: "अनपिन", del: "डिलीट", claim: "क्लेम",
like_rule: "100 लाइक पर लिखने वाले को 1 SP मिलता है", sponsored: "विज्ञापन", ad: "लोकल ऐड", pinned: "पिन किया हुआ",
sp_title: "स्फीयर पॉइंट", sp_bal: "SP बैलेंस", hold: "भेजने या पाने के लिए दबाकर रखें", receive: "पाएं",
buy: "Pi से SP खरीदें", buy_note: "भुगतान आपके Pi Wallet से होगा। SP वापस Pi में नहीं बदलेगा और खरीद का रिफंड नहीं होगा।",
watch: "विज्ञापन देखें, SP पाएं", hist: "SP का हिसाब", no_hist: "अभी कोई लेनदेन नहीं", settings: "सेटिंग", edit: "प्रोफाइल बदलें", admin: "एडमिन पैनल", lang: "भाषा",
tip_to: "टिप भेजें:", amt: "SP की रकम", e_amt: "उतनी रकम लिखें जितनी आपके पास है।", tip_ok: "टिप भेज दिया", recv_note: "SP पाने के लिए अपना Pi यूजरनेम बताएं:",
pubb: "पब्लिक", privb: "प्राइवेट", priv_note: "यह प्रोफाइल प्राइवेट है।", contact: "कॉन्टैक्ट नंबर", email: "ईमेल",
test_credit: "टेस्ट मोड: SP बिना भुगतान के जोड़ा गया।", copied: "कॉपी हो गया", copy: "\u0915\u0949\u092a\u0940 \u0915\u0930\u0947\u0902", claim_ph: "यह डिसलाइक गलत क्यों है?", claim_ok: "क्लेम एडमिन को भेज दिया",
h_buy: "Pi से खरीदा (टेस्ट)", h_tip: "टिप भेजा:", h_reward: "रिवॉर्ड", h_send: "भेजा:", lim_dis: "आज की डिसलाइक लिमिट पूरी हो गई।",
hold_tip: "प्रोफाइल देखने के लिए नाम छुएं। और विकल्पों के लिए दबाकर रखें।",
a_rules: "बदलने वाले नियम", a_ads: "लोकल विज्ञापन पोस्ट करें", a_title: "विज्ञापन का शीर्षक", a_text: "विज्ञापन का टेक्स्ट", a_link: "लिंक या फोन नंबर", a_city: "शहर (खाली = सबको)",
a_from: "कब से", a_to: "कब तक", a_places: "कहाँ दिखाना है", a_ticker: "हेडर टिकर", a_feed: "पोस्ट फीड", a_chats: "चैट रूम", a_meet: "मीटिंग",
a_post: "विज्ञापन पोस्ट करें", a_live: "चल रहे विज्ञापन", a_claims: "डिसलाइक क्लेम", a_ok: "मंजूर", a_no: "खारिज", a_reset: "टेस्ट डाटा रीसेट करें",
a_reset_q: "इससे इस फोन की चैट, पोस्ट, SP और विज्ञापन साफ हो जाएंगे। आपकी प्रोफाइल रहेगी।", a_yes: "हाँ, रीसेट करें", a_colors: "टिकर के रंग", a_bg: "पृष्ठभूमि", a_fg: "अक्षर", a_saved: "सेव हो गया",
a_note: "चरण 1 में डाटा सिर्फ इसी फोन में रहता है। सबका साझा डाटा और असली जांच चरण 2 में सर्वर के साथ आएगी।"
},
gu: {
signin: "Pi સાઇન ઇન", cont: "આગળ વધો", skip: "છોડો", name: "સાચું નામ", mobile: "મોબાઇલ નંબર", country: "દેશ", state: "રાજ્ય", city: "શહેર",
p_title: "તમારી પ્રોફાઇલ પૂરી કરો", photo: "પ્રોફાઇલ ફોટો", upload: "ફોટો અપલોડ કરો", submit: "પ્રોફાઇલ સબમિટ કરો", save: "સેવ કરો",
n_chats: "ચેટ", n_meet: "મીટિંગ", n_feed: "ફીડ", n_rew: "રિવોર્ડ", t_chats: "ચેટ", t_groups: "ગ્રુપ", t_channels: "ચેનલ",
new_chat: "નવી ચેટ", new_group: "નવું ગ્રુપ", new_channel: "નવી ચેનલ", create: "બનાવો", cancel: "રદ કરો", close: "બંધ કરો",
msg_ph: "સંદેશ લખો", send: "મોકલો", members: "સભ્યો", back: "પાછળ", post_ph: "પોસ્ટ લખો", post: "પોસ્ટ",
like: "લાઇક", dislike: "ડિસલાઇક", share: "શેર", tip: "SP ટિપ", pin: "પિન", unpin: "અનપિન", del: "ડિલીટ", claim: "ક્લેમ",
join: "જોડાઓ", start: "શરૂ કરો", m_title: "ક્લાઉડ મીટિંગ", sp_title: "સ્ફિયર પોઇન્ટ", sp_bal: "SP બેલેન્સ",
receive: "મેળવો", buy: "Pi થી SP ખરીદો", hist: "SP ઇતિહાસ", settings: "સેટિંગ્સ", edit: "પ્રોફાઇલ બદલો", lang: "ભાષા", sponsored: "જાહેરાત"
},
mr: {
signin: "Pi साइन इन", cont: "पुढे जा", skip: "वगळा", name: "खरे नाव", mobile: "मोबाइल नंबर", country: "देश", state: "राज्य", city: "शहर",
p_title: "तुमची प्रोफाइल पूर्ण करा", photo: "प्रोफाइल फोटो", upload: "फोटो अपलोड करा", submit: "प्रोफाइल सबमिट करा", save: "जतन करा",
n_chats: "चॅट", n_meet: "मीटिंग", n_feed: "फीड", n_rew: "रिवॉर्ड", t_chats: "चॅट", t_groups: "ग्रुप", t_channels: "चॅनल",
new_chat: "नवीन चॅट", new_group: "नवीन ग्रुप", new_channel: "नवीन चॅनल", create: "तयार करा", cancel: "रद्द करा", close: "बंद करा",
msg_ph: "संदेश लिहा", send: "पाठवा", members: "सदस्य", back: "मागे", post_ph: "पोस्ट लिहा", post: "पोस्ट",
like: "लाइक", dislike: "डिसलाइक", share: "शेअर", tip: "SP टिप", pin: "पिन", unpin: "अनपिन", del: "हटवा", claim: "क्लेम",
join: "सामील व्हा", start: "सुरू करा", m_title: "क्लाउड मीटिंग", sp_title: "स्फिअर पॉइंट", sp_bal: "SP शिल्लक",
receive: "मिळवा", buy: "Pi ने SP खरेदी करा", hist: "SP इतिहास", settings: "सेटिंग्ज", edit: "प्रोफाइल बदला", lang: "भाषा", sponsored: "जाहिरात"
},
kn: {
signin: "Pi ಸೈನ್ ಇನ್", cont: "ಮುಂದುವರಿಸಿ", skip: "ಬಿಡಿ", name: "ನಿಜವಾದ ಹೆಸರು", mobile: "ಮೊಬೈಲ್ ಸಂಖ್ಯೆ", country: "ದೇಶ", state: "ರಾಜ್ಯ", city: "ನಗರ",
p_title: "ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಪೂರ್ಣಗೊಳಿಸಿ", photo: "ಪ್ರೊಫೈಲ್ ಫೋಟೋ", upload: "ಫೋಟೋ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ", submit: "ಪ್ರೊಫೈಲ್ ಸಲ್ಲಿಸಿ", save: "ಉಳಿಸಿ",
n_chats: "ಚಾಟ್", n_meet: "ಸಭೆಗಳು", n_feed: "ಫೀಡ್", n_rew: "ಬಹುಮಾನ", t_chats: "ಚಾಟ್", t_groups: "ಗುಂಪುಗಳು", t_channels: "ಚಾನೆಲ್‌ಗಳು",
new_chat: "ಹೊಸ ಚಾಟ್", new_group: "ಹೊಸ ಗುಂಪು", new_channel: "ಹೊಸ ಚಾನೆಲ್", create: "ರಚಿಸಿ", cancel: "ರದ್ದುಮಾಡಿ", close: "ಮುಚ್ಚಿ",
msg_ph: "ಸಂದೇಶ ಬರೆಯಿರಿ", send: "ಕಳುಹಿಸಿ", members: "ಸದಸ್ಯರು", back: "ಹಿಂದೆ", post_ph: "ಪೋಸ್ಟ್ ಬರೆಯಿರಿ", post: "ಪೋಸ್ಟ್",
like: "ಲೈಕ್", dislike: "ಡಿಸ್‌ಲೈಕ್", share: "ಹಂಚಿಕೊಳ್ಳಿ", tip: "SP ಟಿಪ್", pin: "ಪಿನ್", unpin: "ಅನ್‌ಪಿನ್", del: "ಅಳಿಸಿ", claim: "ಕ್ಲೇಮ್",
join: "ಸೇರಿ", start: "ಪ್ರಾರಂಭಿಸಿ", m_title: "ಕ್ಲೌಡ್ ಸಭೆಗಳು", sp_title: "ಸ್ಫಿಯರ್ ಪಾಯಿಂಟ್ಸ್", sp_bal: "SP ಬಾಕಿ",
receive: "ಸ್ವೀಕರಿಸಿ", buy: "Pi ಯಿಂದ SP ಖರೀದಿಸಿ", hist: "SP ಇತಿಹಾಸ", settings: "ಸೆಟ್ಟಿಂಗ್‌ಗಳು", edit: "ಪ್ರೊಫೈಲ್ ಬದಲಿಸಿ", lang: "ಭಾಷೆ", sponsored: "ಜಾಹೀರಾತು"
},
ta: {
signin: "Pi உள்நுழை", cont: "தொடரவும்", skip: "தவிர்", name: "உண்மையான பெயர்", mobile: "மொபைல் எண்", country: "நாடு", state: "மாநிலம்", city: "நகரம்",
p_title: "உங்கள் சுயவிவரத்தை நிரப்பவும்", photo: "சுயவிவரப் படம்", upload: "படத்தைப் பதிவேற்றவும்", submit: "சமர்ப்பிக்கவும்", save: "சேமி",
n_chats: "அரட்டை", n_meet: "கூட்டங்கள்", n_feed: "ஊட்டம்", n_rew: "வெகுமதி", t_chats: "அரட்டை", t_groups: "குழுக்கள்", t_channels: "சேனல்கள்",
new_chat: "புதிய அரட்டை", new_group: "புதிய குழு", new_channel: "புதிய சேனல்", create: "உருவாக்கு", cancel: "ரத்து", close: "மூடு",
msg_ph: "செய்தி எழுதவும்", send: "அனுப்பு", members: "உறுப்பினர்கள்", back: "பின்செல்", post_ph: "பதிவு எழுதவும்", post: "பதிவிடு",
like: "விருப்பம்", dislike: "விருப்பமில்லை", share: "பகிர்", tip: "SP டிப்", pin: "பின்", unpin: "பின் நீக்கு", del: "நீக்கு", claim: "கோரிக்கை",
join: "சேர்", start: "தொடங்கு", m_title: "கிளவுட் கூட்டங்கள்", sp_title: "ஸ்பியர் பாயிண்ட்ஸ்", sp_bal: "SP இருப்பு",
receive: "பெறு", buy: "Pi மூலம் SP வாங்கு", hist: "SP வரலாறு", settings: "அமைப்புகள்", edit: "சுயவிவரத்தை மாற்று", lang: "மொழி", sponsored: "விளம்பரம்"
},
te: {
signin: "Pi సైన్ ఇన్", cont: "కొనసాగించు", skip: "దాటవేయి", name: "అసలు పేరు", mobile: "మొబైల్ నంబర్", country: "దేశం", state: "రాష్ట్రం", city: "నగరం",
p_title: "మీ ప్రొఫైల్ పూర్తి చేయండి", photo: "ప్రొఫైల్ ఫోటో", upload: "ఫోటో అప్‌లోడ్ చేయండి", submit: "ప్రొఫైల్ సమర్పించండి", save: "సేవ్ చేయి",
n_chats: "చాట్", n_meet: "సమావేశాలు", n_feed: "ఫీడ్", n_rew: "రివార్డ్స్", t_chats: "చాట్", t_groups: "గ్రూపులు", t_channels: "ఛానెల్స్",
new_chat: "కొత్త చాట్", new_group: "కొత్త గ్రూప్", new_channel: "కొత్త ఛానెల్", create: "సృష్టించు", cancel: "రద్దు చేయి", close: "మూసివేయి",
msg_ph: "సందేశం రాయండి", send: "పంపు", members: "సభ్యులు", back: "వెనుకకు", post_ph: "పోస్ట్ రాయండి", post: "పోస్ట్",
like: "లైక్", dislike: "డిస్‌లైక్", share: "షేర్", tip: "SP టిప్", pin: "పిన్", unpin: "అన్‌పిన్", del: "తొలగించు", claim: "క్లెయిమ్",
join: "చేరండి", start: "ప్రారంభించు", m_title: "క్లౌడ్ సమావేశాలు", sp_title: "స్ఫియర్ పాయింట్లు", sp_bal: "SP బ్యాలెన్స్",
receive: "స్వీకరించు", buy: "Pi తో SP కొనండి", hist: "SP చరిత్ర", settings: "సెట్టింగ్‌లు", edit: "ప్రొఫైల్ మార్చు", lang: "భాష", sponsored: "ప్రకటన"
},
as: {
signin: "Pi চাইন ইন", cont: "আগবাঢ়ক", skip: "এৰক", name: "প্ৰকৃত নাম", mobile: "মবাইল নম্বৰ", country: "দেশ", state: "ৰাজ্য", city: "চহৰ",
p_title: "আপোনাৰ প্ৰোফাইল সম্পূৰ্ণ কৰক", photo: "প্ৰোফাইল ফটো", upload: "ফটো আপলোড কৰক", submit: "প্ৰোফাইল জমা দিয়ক", save: "সংৰক্ষণ কৰক",
n_chats: "চাট", n_meet: "মিটিং", n_feed: "ফিড", n_rew: "পুৰস্কাৰ", t_chats: "চাট", t_groups: "গ্ৰুপ", t_channels: "চেনেল",
new_chat: "নতুন চাট", new_group: "নতুন গ্ৰুপ", new_channel: "নতুন চেনেল", create: "সৃষ্টি কৰক", cancel: "বাতিল কৰক", close: "বন্ধ কৰক",
msg_ph: "বাৰ্তা লিখক", send: "পঠিয়াওক", members: "সদস্য", back: "উভতি যাওক", post_ph: "পোষ্ট লিখক", post: "পোষ্ট",
like: "লাইক", dislike: "ডিচলাইক", share: "শ্বেয়াৰ", tip: "SP টিপ", pin: "পিন", unpin: "আনপিন", del: "মচক", claim: "দাবী",
join: "যোগদান কৰক", start: "আৰম্ভ কৰক", m_title: "ক্লাউড মিটিং", sp_title: "স্ফিয়াৰ পইণ্ট", sp_bal: "SP বেলেন্স",
receive: "গ্ৰহণ কৰক", buy: "Pi ৰে SP কিনক", hist: "SP ইতিহাস", settings: "চেটিংছ", edit: "প্ৰোফাইল সলাওক", lang: "ভাষা", sponsored: "বিজ্ঞাপন"
},
zh: {
signin: "Pi 登录", cont: "继续", skip: "跳过", name: "真实姓名", mobile: "手机号码", country: "国家", state: "省/州", city: "城市",
p_title: "完善您的资料", photo: "头像", upload: "上传图片", submit: "提交资料", save: "保存",
n_chats: "聊天", n_meet: "会议", n_feed: "动态", n_rew: "奖励", t_chats: "聊天", t_groups: "群组", t_channels: "频道",
new_chat: "新聊天", new_group: "新建群组", new_channel: "新建频道", create: "创建", cancel: "取消", close: "关闭",
msg_ph: "输入消息", send: "发送", members: "位成员", back: "返回", post_ph: "写帖子", post: "发布",
like: "赞", dislike: "踩", share: "分享", tip: "打赏 SP", pin: "置顶", unpin: "取消置顶", del: "删除", claim: "申诉",
join: "加入", start: "开始", m_title: "云会议", sp_title: "Sphere 积分", sp_bal: "SP 余额",
receive: "接收", buy: "用 Pi 购买 SP", hist: "SP 记录", settings: "设置", edit: "编辑资料", lang: "语言", sponsored: "广告"
},
ja: {
signin: "Pi サインイン", cont: "続ける", skip: "スキップ", name: "本名", mobile: "携帯電話番号", country: "国", state: "都道府県", city: "市区町村",
p_title: "プロフィールを入力", photo: "プロフィール写真", upload: "画像をアップロード", submit: "プロフィールを送信", save: "保存",
n_chats: "チャット", n_meet: "会議", n_feed: "フィード", n_rew: "リワード", t_chats: "チャット", t_groups: "グループ", t_channels: "チャンネル",
new_chat: "新しいチャット", new_group: "新しいグループ", new_channel: "新しいチャンネル", create: "作成", cancel: "キャンセル", close: "閉じる",
msg_ph: "メッセージを入力", send: "送信", members: "人のメンバー", back: "戻る", post_ph: "投稿を書く", post: "投稿",
like: "いいね", dislike: "よくないね", share: "共有", tip: "SP チップ", pin: "ピン留め", unpin: "ピン解除", del: "削除", claim: "申し立て",
join: "参加", start: "開始", m_title: "クラウド会議", sp_title: "Sphere ポイント", sp_bal: "SP 残高",
receive: "受け取る", buy: "Pi で SP を購入", hist: "SP 履歴", settings: "設定", edit: "プロフィールを編集", lang: "言語", sponsored: "広告"
},
id: {
tag: "Aplikasi komunitas Pi", signin: "Masuk dengan Pi", cont: "Lanjut", skip: "Lewati", sound: "Nyalakan suara", name: "Nama asli", mobile: "Nomor ponsel", country: "Negara", state: "Provinsi", city: "Kota",
p_title: "Lengkapi profil Anda", photo: "Foto profil", upload: "Unggah gambar", submit: "Kirim profil", save: "Simpan",
vis: "Visibilitas profil", pub: "Publik · dapat SP", priv: "Privat · tanpa SP", confirm: "Saya menyatakan data ini benar",
n_chats: "Obrolan", n_meet: "Rapat", n_feed: "Beranda", n_rew: "Hadiah", t_chats: "Obrolan", t_groups: "Grup", t_channels: "Kanal",
new_chat: "Obrolan baru", new_group: "Grup baru", new_channel: "Kanal baru", create: "Buat", cancel: "Batal", close: "Tutup",
msg_ph: "Tulis pesan", send: "Kirim", members: "anggota", back: "Kembali", post_ph: "Tulis postingan", post: "Posting",
like: "Suka", dislike: "Tidak suka", share: "Bagikan", tip: "Tip SP", pin: "Sematkan", unpin: "Lepas sematan", del: "Hapus", claim: "Klaim",
join: "Gabung", start: "Mulai", m_title: "Rapat cloud", sp_title: "Sphere Points", sp_bal: "Saldo SP",
receive: "Terima", buy: "Beli SP dengan Pi", hist: "Riwayat SP", settings: "Pengaturan", edit: "Ubah profil", lang: "Bahasa", sponsored: "Iklan"
}
};

/* ---- sign-in and small extras ---- */
Object.assign(window.PS_I18N.en, {
need_pi: "Sign in with Pi to continue. This app works inside Pi Browser.", e_pic: "This image could not be used. Try another photo.",
ad_default: "Local ads appear here", prev: "Preview only. This box is not in the real app."
});
Object.assign(window.PS_I18N.hi, {
need_pi: "आगे बढ़ने के लिए Pi से साइन इन करें। यह ऐप Pi Browser के अंदर चलता है।", e_pic: "यह फोटो नहीं लग पाई। दूसरी फोटो चुनें।",
ad_default: "लोकल विज्ञापन यहाँ चलेंगे", prev: "सिर्फ प्रीव्यू के लिए। असली ऐप में यह बॉक्स नहीं होगा।"
});
Object.assign(window.PS_I18N.gu, {
tag: "Pi સમુદાય એપ", signin_title: "Pi થી સાઇન ઇન કરો", need_pi: "આગળ વધવા Pi થી સાઇન ઇન કરો. આ એપ Pi Browser ની અંદર ચાલે છે.", user_ph: "Pi યુઝરનેમ", sound: "અવાજ ચાલુ કરો",
p_sub: "આ ફોર્મ ભર્યા પછી જ ચેટ, મીટિંગ, ફીડ અને રિવોર્ડ ખુલશે.", gmail: "જીમેલ", vis: "પ્રોફાઇલ કોને દેખાય", pub: "પબ્લિક · SP મળશે", priv: "પ્રાઇવેટ · SP નહીં",
warn: "ખોટી પ્રોફાઇલ માહિતી ભરશો તો તમને સ્ફિયર પોઇન્ટ (SP) નહીં મળે. તમારી સાચી માહિતી ભરો.", confirm: "હું ખાતરી આપું છું કે આ માહિતી સાચી છે",
e_req: "બધાં ખાનાં ભરો અને બોક્સ પર ટિક કરો.", e_mail: "સાચું જીમેલ સરનામું લખો.", e_mob: "સાચો મોબાઇલ નંબર લખો.", e_pic: "આ ફોટો વાપરી શકાયો નથી. બીજો ફોટો પસંદ કરો.",
name_ph: "નામ", summary: "AI ચેટ સારાંશ", soon: "આ આગળના તબક્કામાં જોડાશે.", empty: "હજી અહીં કંઈ નથી", ch_only: "ચેનલમાં ફક્ત માલિક પોસ્ટ કરી શકે છે.",
m_create: "મીટિંગ ગ્રુપ બનાવો", m_join: "લાઇવ મીટિંગમાં જોડાઓ", m_id: "મીટિંગ આઈડી લખો", m_yours: "તમારા મીટિંગ ગ્રુપ", m_rule: "મીટિંગમાં દર 5 લોકો પર હોસ્ટને 1 SP મળે છે.", m_id_lbl: "મીટિંગ આઈડી",
like_rule: "100 લાઇક પર લેખકને 1 SP મળે છે", ad: "લોકલ જાહેરાત", ad_default: "લોકલ જાહેરાતો અહીં ચાલશે", pinned: "પિન કરેલું", hold: "મોકલવા કે મેળવવા દબાવી રાખો",
buy_note: "ચુકવણી તમારા Pi Wallet માંથી થશે. SP પાછા Pi માં બદલાશે નહીં અને ખરીદીનું રિફંડ મળશે નહીં.", watch: "જાહેરાત જુઓ, SP મેળવો", no_hist: "હજી કોઈ વ્યવહાર નથી", admin: "એડમિન પેનલ",
tip_to: "ટિપ મોકલો:", amt: "SP રકમ", e_amt: "તમારી પાસે હોય એટલી રકમ લખો.", tip_ok: "ટિપ મોકલાઈ ગઈ", recv_note: "SP મેળવવા તમારું Pi યુઝરનેમ આપો:",
pubb: "પબ્લિક", privb: "પ્રાઇવેટ", priv_note: "આ પ્રોફાઇલ પ્રાઇવેટ છે.", contact: "સંપર્ક નંબર", email: "ઈમેલ", test_credit: "ટેસ્ટ મોડ: ચુકવણી વગર SP ઉમેરાયા.",
copied: "કોપી થયું", copy: "કોપી કરો", claim_ph: "આ ડિસલાઇક ખોટું કેમ છે?", claim_ok: "ક્લેમ એડમિનને મોકલાયો", h_buy: "Pi થી ખરીદ્યું (ટેસ્ટ)", h_tip: "ટિપ મોકલી:", h_reward: "રિવોર્ડ", h_send: "મોકલ્યું:",
lim_dis: "આજની ડિસલાઇક મર્યાદા પૂરી થઈ.", hold_tip: "પ્રોફાઇલ જોવા નામ પર ટેપ કરો. વધુ વિકલ્પો માટે દબાવી રાખો."
});
Object.assign(window.PS_I18N.mr, {
tag: "Pi समुदाय ॲप", signin_title: "Pi ने साइन इन करा", need_pi: "पुढे जाण्यासाठी Pi ने साइन इन करा. हे ॲप Pi Browser मध्ये चालते.", user_ph: "Pi युजरनेम", sound: "आवाज सुरू करा",
p_sub: "हा फॉर्म भरल्यानंतरच चॅट, मीटिंग, फीड आणि रिवॉर्ड उघडतील.", gmail: "जीमेल", vis: "प्रोफाइल कोणाला दिसेल", pub: "पब्लिक · SP मिळेल", priv: "प्रायव्हेट · SP नाही",
warn: "चुकीची प्रोफाइल माहिती भरल्यास तुम्हाला स्फिअर पॉइंट (SP) मिळणार नाहीत. तुमची खरी माहिती भरा.", confirm: "ही माहिती बरोबर असल्याची मी खात्री देतो",
e_req: "सर्व रकाने भरा आणि बॉक्सवर टिक करा.", e_mail: "योग्य जीमेल पत्ता लिहा.", e_mob: "योग्य मोबाइल नंबर लिहा.", e_pic: "हा फोटो वापरता आला नाही. दुसरा फोटो निवडा.",
name_ph: "नाव", summary: "AI चॅट सारांश", soon: "हे पुढच्या टप्प्यात जोडले जाईल.", empty: "इथे अजून काही नाही", ch_only: "चॅनलमध्ये फक्त मालक पोस्ट करू शकतो.",
m_create: "मीटिंग ग्रुप तयार करा", m_join: "लाइव्ह मीटिंगमध्ये सामील व्हा", m_id: "मीटिंग आयडी लिहा", m_yours: "तुमचे मीटिंग ग्रुप", m_rule: "मीटिंगमधील प्रत्येक 5 लोकांमागे होस्टला 1 SP मिळतो.", m_id_lbl: "मीटिंग आयडी",
like_rule: "100 लाइकवर लेखकाला 1 SP मिळतो", ad: "लोकल जाहिरात", ad_default: "लोकल जाहिराती इथे चालतील", pinned: "पिन केलेले", hold: "पाठवण्यासाठी किंवा मिळवण्यासाठी दाबून ठेवा",
buy_note: "पेमेंट तुमच्या Pi Wallet मधून होईल. SP परत Pi मध्ये बदलता येणार नाही आणि खरेदीचा परतावा मिळणार नाही.", watch: "जाहिरात पहा, SP मिळवा", no_hist: "अजून कोणताही व्यवहार नाही", admin: "ॲडमिन पॅनेल",
tip_to: "टिप पाठवा:", amt: "SP रक्कम", e_amt: "तुमच्याकडे असलेली रक्कम लिहा.", tip_ok: "टिप पाठवली", recv_note: "SP मिळवण्यासाठी तुमचे Pi युजरनेम सांगा:",
pubb: "पब्लिक", privb: "प्रायव्हेट", priv_note: "ही प्रोफाइल प्रायव्हेट आहे.", contact: "संपर्क क्रमांक", email: "ईमेल", test_credit: "टेस्ट मोड: पेमेंटशिवाय SP जोडले.",
copied: "कॉपी झाले", copy: "कॉपी करा", claim_ph: "हा डिसलाइक चुकीचा का आहे?", claim_ok: "क्लेम ॲडमिनकडे पाठवला", h_buy: "Pi ने खरेदी (टेस्ट)", h_tip: "टिप पाठवली:", h_reward: "रिवॉर्ड", h_send: "पाठवले:",
lim_dis: "आजची डिसलाइक मर्यादा संपली.", hold_tip: "प्रोफाइल पाहण्यासाठी नावावर टॅप करा. आणखी पर्यायांसाठी दाबून ठेवा."
});
Object.assign(window.PS_I18N.kn, {
tag: "Pi ಸಮುದಾಯ ಆ್ಯಪ್", signin_title: "Pi ಮೂಲಕ ಸೈನ್ ಇನ್ ಮಾಡಿ", need_pi: "ಮುಂದುವರಿಯಲು Pi ಮೂಲಕ ಸೈನ್ ಇನ್ ಮಾಡಿ. ಈ ಆ್ಯಪ್ Pi Browser ಒಳಗೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ.", user_ph: "Pi ಬಳಕೆದಾರ ಹೆಸರು", sound: "ಧ್ವನಿ ಆನ್ ಮಾಡಿ",
p_sub: "ಈ ಫಾರ್ಮ್ ಸಲ್ಲಿಸಿದ ನಂತರವೇ ಚಾಟ್, ಸಭೆ, ಫೀಡ್ ಮತ್ತು ಬಹುಮಾನಗಳು ತೆರೆಯುತ್ತವೆ.", gmail: "ಜಿಮೇಲ್", vis: "ಪ್ರೊಫೈಲ್ ಯಾರಿಗೆ ಕಾಣಬೇಕು", pub: "ಸಾರ್ವಜನಿಕ · SP ಸಿಗುತ್ತದೆ", priv: "ಖಾಸಗಿ · SP ಇಲ್ಲ",
warn: "ತಪ್ಪು ಪ್ರೊಫೈಲ್ ಮಾಹಿತಿ ನೀಡಿದರೆ ನಿಮಗೆ ಸ್ಫಿಯರ್ ಪಾಯಿಂಟ್ಸ್ (SP) ಸಿಗುವುದಿಲ್ಲ. ನಿಮ್ಮ ನಿಜವಾದ ಮಾಹಿತಿ ತುಂಬಿರಿ.", confirm: "ಈ ಮಾಹಿತಿ ಸರಿಯಾಗಿದೆ ಎಂದು ನಾನು ದೃಢೀಕರಿಸುತ್ತೇನೆ",
e_req: "ಎಲ್ಲಾ ಕಾಲಂಗಳನ್ನು ತುಂಬಿ ಮತ್ತು ಬಾಕ್ಸ್ ಟಿಕ್ ಮಾಡಿ.", e_mail: "ಸರಿಯಾದ ಜಿಮೇಲ್ ವಿಳಾಸ ನಮೂದಿಸಿ.", e_mob: "ಸರಿಯಾದ ಮೊಬೈಲ್ ಸಂಖ್ಯೆ ನಮೂದಿಸಿ.", e_pic: "ಈ ಚಿತ್ರವನ್ನು ಬಳಸಲಾಗಲಿಲ್ಲ. ಬೇರೆ ಫೋಟೋ ಆಯ್ಕೆಮಾಡಿ.",
name_ph: "ಹೆಸರು", summary: "AI ಚಾಟ್ ಸಾರಾಂಶ", soon: "ಇದು ಮುಂದಿನ ಹಂತದಲ್ಲಿ ಸೇರುತ್ತದೆ.", empty: "ಇಲ್ಲಿ ಇನ್ನೂ ಏನೂ ಇಲ್ಲ", ch_only: "ಚಾನೆಲ್‌ನಲ್ಲಿ ಮಾಲೀಕರು ಮಾತ್ರ ಪೋಸ್ಟ್ ಮಾಡಬಹುದು.",
m_create: "ಸಭೆ ಗುಂಪು ರಚಿಸಿ", m_join: "ಲೈವ್ ಸಭೆಗೆ ಸೇರಿ", m_id: "ಸಭೆ ಐಡಿ ನಮೂದಿಸಿ", m_yours: "ನಿಮ್ಮ ಸಭೆ ಗುಂಪುಗಳು", m_rule: "ಸಭೆಯಲ್ಲಿ ಪ್ರತಿ 5 ಜನರಿಗೆ ಹೋಸ್ಟ್‌ಗೆ 1 SP ಸಿಗುತ್ತದೆ.", m_id_lbl: "ಸಭೆ ಐಡಿ",
like_rule: "100 ಲೈಕ್‌ಗಳಿಗೆ ಲೇಖಕರಿಗೆ 1 SP ಸಿಗುತ್ತದೆ", ad: "ಸ್ಥಳೀಯ ಜಾಹೀರಾತು", ad_default: "ಸ್ಥಳೀಯ ಜಾಹೀರಾತುಗಳು ಇಲ್ಲಿ ಕಾಣುತ್ತವೆ", pinned: "ಪಿನ್ ಮಾಡಲಾಗಿದೆ", hold: "ಕಳುಹಿಸಲು ಅಥವಾ ಸ್ವೀಕರಿಸಲು ಒತ್ತಿ ಹಿಡಿಯಿರಿ",
buy_note: "ಪಾವತಿ ನಿಮ್ಮ Pi Wallet ನಿಂದ ಆಗುತ್ತದೆ. SP ಅನ್ನು ಮತ್ತೆ Pi ಗೆ ಬದಲಾಯಿಸಲು ಆಗುವುದಿಲ್ಲ ಮತ್ತು ಖರೀದಿಗೆ ಮರುಪಾವತಿ ಇಲ್ಲ.", watch: "ಜಾಹೀರಾತು ನೋಡಿ, SP ಗಳಿಸಿ", no_hist: "ಇನ್ನೂ ಯಾವುದೇ ವಹಿವಾಟು ಇಲ್ಲ", admin: "ಅಡ್ಮಿನ್ ಪ್ಯಾನೆಲ್",
tip_to: "ಟಿಪ್ ಕಳುಹಿಸಿ:", amt: "SP ಮೊತ್ತ", e_amt: "ನಿಮ್ಮ ಬಳಿ ಇರುವ ಮೊತ್ತವನ್ನು ನಮೂದಿಸಿ.", tip_ok: "ಟಿಪ್ ಕಳುಹಿಸಲಾಗಿದೆ", recv_note: "SP ಸ್ವೀಕರಿಸಲು ನಿಮ್ಮ Pi ಬಳಕೆದಾರ ಹೆಸರು ಹಂಚಿಕೊಳ್ಳಿ:",
pubb: "ಸಾರ್ವಜನಿಕ", privb: "ಖಾಸಗಿ", priv_note: "ಈ ಪ್ರೊಫೈಲ್ ಖಾಸಗಿಯಾಗಿದೆ.", contact: "ಸಂಪರ್ಕ ಸಂಖ್ಯೆ", email: "ಇಮೇಲ್", test_credit: "ಟೆಸ್ಟ್ ಮೋಡ್: ಪಾವತಿ ಇಲ್ಲದೆ SP ಸೇರಿಸಲಾಗಿದೆ.",
copied: "ನಕಲಿಸಲಾಗಿದೆ", copy: "ನಕಲಿಸಿ", claim_ph: "ಈ ಡಿಸ್‌ಲೈಕ್ ಏಕೆ ತಪ್ಪು?", claim_ok: "ಕ್ಲೇಮ್ ಅಡ್ಮಿನ್‌ಗೆ ಕಳುಹಿಸಲಾಗಿದೆ", h_buy: "Pi ಯಿಂದ ಖರೀದಿ (ಟೆಸ್ಟ್)", h_tip: "ಟಿಪ್ ಕಳುಹಿಸಲಾಗಿದೆ:", h_reward: "ಬಹುಮಾನ", h_send: "ಕಳುಹಿಸಲಾಗಿದೆ:",
lim_dis: "ಇಂದಿನ ಡಿಸ್‌ಲೈಕ್ ಮಿತಿ ಮುಗಿದಿದೆ.", hold_tip: "ಪ್ರೊಫೈಲ್ ನೋಡಲು ಹೆಸರನ್ನು ಟ್ಯಾಪ್ ಮಾಡಿ. ಹೆಚ್ಚಿನ ಆಯ್ಕೆಗಳಿಗೆ ಒತ್ತಿ ಹಿಡಿಯಿರಿ."
});
Object.assign(window.PS_I18N.ta, {
tag: "Pi சமூக செயலி", signin_title: "Pi மூலம் உள்நுழையவும்", need_pi: "தொடர Pi மூலம் உள்நுழையவும். இந்த செயலி Pi Browser உள்ளே இயங்கும்.", user_ph: "Pi பயனர்பெயர்", sound: "ஒலியை இயக்கு",
p_sub: "இந்தப் படிவத்தைச் சமர்ப்பித்த பிறகே அரட்டை, கூட்டம், ஊட்டம், வெகுமதி திறக்கும்.", gmail: "ஜிமெயில்", vis: "சுயவிவரம் யாருக்குத் தெரியும்", pub: "பொது · SP கிடைக்கும்", priv: "தனிப்பட்டது · SP இல்லை",
warn: "தவறான சுயவிவரத் தகவல் கொடுத்தால் உங்களுக்கு ஸ்பியர் பாயிண்ட்ஸ் (SP) கிடைக்காது. உங்கள் உண்மையான தகவலை நிரப்பவும்.", confirm: "இந்த விவரங்கள் சரியானவை என உறுதிப்படுத்துகிறேன்",
e_req: "எல்லா புலங்களையும் நிரப்பி பெட்டியில் டிக் செய்யவும்.", e_mail: "சரியான ஜிமெயில் முகவரியை உள்ளிடவும்.", e_mob: "சரியான மொபைல் எண்ணை உள்ளிடவும்.", e_pic: "இந்தப் படத்தைப் பயன்படுத்த முடியவில்லை. வேறு படத்தைத் தேர்ந்தெடுக்கவும்.",
name_ph: "பெயர்", summary: "AI அரட்டைச் சுருக்கம்", soon: "இது அடுத்த கட்டத்தில் இணைக்கப்படும்.", empty: "இங்கே இன்னும் எதுவும் இல்லை", ch_only: "சேனலில் உரிமையாளர் மட்டுமே பதிவிட முடியும்.",
m_create: "கூட்டக் குழுவை உருவாக்கு", m_join: "நேரலைக் கூட்டத்தில் சேர்", m_id: "கூட்ட ஐடியை உள்ளிடவும்", m_yours: "உங்கள் கூட்டக் குழுக்கள்", m_rule: "கூட்டத்தில் ஒவ்வொரு 5 பேருக்கும் நடத்துநருக்கு 1 SP கிடைக்கும்.", m_id_lbl: "கூட்ட ஐடி",
like_rule: "100 விருப்பங்களுக்கு எழுதியவருக்கு 1 SP கிடைக்கும்", ad: "உள்ளூர் விளம்பரம்", ad_default: "உள்ளூர் விளம்பரங்கள் இங்கே தோன்றும்", pinned: "பின் செய்யப்பட்டது", hold: "அனுப்ப அல்லது பெற அழுத்திப் பிடிக்கவும்",
buy_note: "கட்டணம் உங்கள் Pi Wallet இலிருந்து செலுத்தப்படும். SP ஐ மீண்டும் Pi ஆக மாற்ற முடியாது; வாங்கியதற்கு பணம் திரும்பக் கிடைக்காது.", watch: "விளம்பரம் பார்த்து SP பெறுங்கள்", no_hist: "இன்னும் பரிவர்த்தனை இல்லை", admin: "நிர்வாகப் பலகம்",
tip_to: "டிப் அனுப்பு:", amt: "SP தொகை", e_amt: "உங்களிடம் உள்ள தொகையை உள்ளிடவும்.", tip_ok: "டிப் அனுப்பப்பட்டது", recv_note: "SP பெற உங்கள் Pi பயனர்பெயரைப் பகிரவும்:",
pubb: "பொது", privb: "தனிப்பட்டது", priv_note: "இந்தச் சுயவிவரம் தனிப்பட்டது.", contact: "தொடர்பு எண்", email: "மின்னஞ்சல்", test_credit: "சோதனை முறை: கட்டணம் இல்லாமல் SP சேர்க்கப்பட்டது.",
copied: "நகலெடுக்கப்பட்டது", copy: "நகலெடு", claim_ph: "இந்த விருப்பமின்மை ஏன் தவறு?", claim_ok: "கோரிக்கை நிர்வாகிக்கு அனுப்பப்பட்டது", h_buy: "Pi மூலம் வாங்கியது (சோதனை)", h_tip: "டிப் அனுப்பியது:", h_reward: "வெகுமதி", h_send: "அனுப்பியது:",
lim_dis: "இன்றைய விருப்பமின்மை வரம்பு முடிந்தது.", hold_tip: "சுயவிவரத்தைப் பார்க்க பெயரைத் தட்டவும். மேலும் விருப்பங்களுக்கு அழுத்திப் பிடிக்கவும்."
});
Object.assign(window.PS_I18N.te, {
tag: "Pi కమ్యూనిటీ యాప్", signin_title: "Pi తో సైన్ ఇన్ చేయండి", need_pi: "కొనసాగడానికి Pi తో సైన్ ఇన్ చేయండి. ఈ యాప్ Pi Browser లోపల పనిచేస్తుంది.", user_ph: "Pi యూజర్‌నేమ్", sound: "సౌండ్ ఆన్ చేయి",
p_sub: "ఈ ఫారం సమర్పించిన తర్వాతే చాట్, సమావేశాలు, ఫీడ్, రివార్డ్స్ తెరుచుకుంటాయి.", gmail: "జీమెయిల్", vis: "ప్రొఫైల్ ఎవరికి కనిపించాలి", pub: "పబ్లిక్ · SP వస్తుంది", priv: "ప్రైవేట్ · SP లేదు",
warn: "తప్పు ప్రొఫైల్ వివరాలు ఇస్తే మీకు స్ఫియర్ పాయింట్లు (SP) రావు. మీ నిజమైన వివరాలు నింపండి.", confirm: "ఈ వివరాలు సరైనవని నేను ధృవీకరిస్తున్నాను",
e_req: "అన్ని ఖాళీలు నింపి బాక్స్‌ను టిక్ చేయండి.", e_mail: "సరైన జీమెయిల్ చిరునామా నమోదు చేయండి.", e_mob: "సరైన మొబైల్ నంబర్ నమోదు చేయండి.", e_pic: "ఈ ఫోటోను ఉపయోగించలేకపోయాం. మరో ఫోటో ఎంచుకోండి.",
name_ph: "పేరు", summary: "AI చాట్ సారాంశం", soon: "ఇది తదుపరి దశలో జతవుతుంది.", empty: "ఇక్కడ ఇంకా ఏమీ లేదు", ch_only: "ఛానెల్‌లో యజమాని మాత్రమే పోస్ట్ చేయగలరు.",
m_create: "సమావేశ గ్రూప్ సృష్టించండి", m_join: "లైవ్ సమావేశంలో చేరండి", m_id: "సమావేశ ఐడీ నమోదు చేయండి", m_yours: "మీ సమావేశ గ్రూపులు", m_rule: "సమావేశంలో ప్రతి 5 మందికి హోస్ట్‌కు 1 SP వస్తుంది.", m_id_lbl: "సమావేశ ఐడీ",
like_rule: "100 లైక్‌లకు రచయితకు 1 SP వస్తుంది", ad: "లోకల్ ప్రకటన", ad_default: "లోకల్ ప్రకటనలు ఇక్కడ కనిపిస్తాయి", pinned: "పిన్ చేయబడింది", hold: "పంపడానికి లేదా స్వీకరించడానికి నొక్కి పట్టుకోండి",
buy_note: "చెల్లింపు మీ Pi Wallet నుండి జరుగుతుంది. SP ను తిరిగి Pi గా మార్చలేరు, కొనుగోళ్లకు రీఫండ్ లేదు.", watch: "ప్రకటన చూసి SP పొందండి", no_hist: "ఇంకా లావాదేవీలు లేవు", admin: "అడ్మిన్ ప్యానెల్",
tip_to: "టిప్ పంపండి:", amt: "SP మొత్తం", e_amt: "మీ వద్ద ఉన్న మొత్తాన్ని నమోదు చేయండి.", tip_ok: "టిప్ పంపబడింది", recv_note: "SP స్వీకరించడానికి మీ Pi యూజర్‌నేమ్ ఇవ్వండి:",
pubb: "పబ్లిక్", privb: "ప్రైవేట్", priv_note: "ఈ ప్రొఫైల్ ప్రైవేట్.", contact: "సంప్రదింపు నంబర్", email: "ఈమెయిల్", test_credit: "టెస్ట్ మోడ్: చెల్లింపు లేకుండా SP జోడించబడింది.",
copied: "కాపీ అయింది", copy: "కాపీ చేయి", claim_ph: "ఈ డిస్‌లైక్ ఎందుకు తప్పు?", claim_ok: "క్లెయిమ్ అడ్మిన్‌కు పంపబడింది", h_buy: "Pi తో కొన్నది (టెస్ట్)", h_tip: "టిప్ పంపారు:", h_reward: "రివార్డ్", h_send: "పంపారు:",
lim_dis: "ఈ రోజు డిస్‌లైక్ పరిమితి పూర్తయింది.", hold_tip: "ప్రొఫైల్ చూడటానికి పేరును నొక్కండి. మరిన్ని ఎంపికలకు నొక్కి పట్టుకోండి."
});
Object.assign(window.PS_I18N.as, {
tag: "Pi সম্প্ৰদায় এপ", signin_title: "Pi ৰে চাইন ইন কৰক", need_pi: "আগবাঢ়িবলৈ Pi ৰে চাইন ইন কৰক। এই এপ Pi Browser ৰ ভিতৰত চলে।", user_ph: "Pi ইউজাৰনেম", sound: "শব্দ অন কৰক",
p_sub: "এই ফৰ্ম জমা দিয়াৰ পিছতহে চাট, মিটিং, ফিড আৰু পুৰস্কাৰ খোল খাব।", gmail: "জিমেইল", vis: "প্ৰোফাইল কোনে দেখিব", pub: "পাব্লিক · SP পাব", priv: "প্ৰাইভেট · SP নাই",
warn: "ভুল প্ৰোফাইল তথ্য দিলে আপুনি স্ফিয়াৰ পইণ্ট (SP) নাপাব। আপোনাৰ প্ৰকৃত তথ্য ভৰাওক।", confirm: "এই তথ্য শুদ্ধ বুলি মই নিশ্চিত কৰিছোঁ",
e_req: "সকলো ঘৰ পূৰণ কৰক আৰু বাকচত টিক দিয়ক।", e_mail: "শুদ্ধ জিমেইল ঠিকনা লিখক।", e_mob: "শুদ্ধ মবাইল নম্বৰ লিখক।", e_pic: "এই ফটো ব্যৱহাৰ কৰিব পৰা নগ'ল। আন এখন ফটো বাছক।",
name_ph: "নাম", summary: "AI চাট সাৰাংশ", soon: "এইটো পৰৱৰ্তী পৰ্যায়ত সংযোগ হ'ব।", empty: "ইয়াত এতিয়াও একো নাই", ch_only: "চেনেলত কেৱল মালিকে পোষ্ট কৰিব পাৰে।",
m_create: "মিটিং গ্ৰুপ সৃষ্টি কৰক", m_join: "লাইভ মিটিঙত যোগ দিয়ক", m_id: "মিটিং আইডি লিখক", m_yours: "আপোনাৰ মিটিং গ্ৰুপ", m_rule: "মিটিঙত প্ৰতি 5 জন লোকৰ বাবে হোষ্টে 1 SP পায়।", m_id_lbl: "মিটিং আইডি",
like_rule: "100 লাইকত লেখকে 1 SP পায়", ad: "স্থানীয় বিজ্ঞাপন", ad_default: "স্থানীয় বিজ্ঞাপন ইয়াত চলিব", pinned: "পিন কৰা", hold: "পঠিয়াবলৈ বা গ্ৰহণ কৰিবলৈ হেঁচি ধৰি ৰাখক",
buy_note: "পৰিশোধ আপোনাৰ Pi Wallet ৰ পৰা হ'ব। SP পুনৰ Pi লৈ সলনি নহয় আৰু ক্ৰয়ৰ ধন ঘূৰাই দিয়া নহয়।", watch: "বিজ্ঞাপন চাওক, SP পাওক", no_hist: "এতিয়াও কোনো লেনদেন নাই", admin: "এডমিন পেনেল",
tip_to: "টিপ পঠিয়াওক:", amt: "SP পৰিমাণ", e_amt: "আপোনাৰ হাতত থকা পৰিমাণ লিখক।", tip_ok: "টিপ পঠোৱা হ'ল", recv_note: "SP পাবলৈ আপোনাৰ Pi ইউজাৰনেম দিয়ক:",
pubb: "পাব্লিক", privb: "প্ৰাইভেট", priv_note: "এই প্ৰোফাইল প্ৰাইভেট।", contact: "যোগাযোগ নম্বৰ", email: "ইমেইল", test_credit: "টেষ্ট মোড: পৰিশোধ নোহোৱাকৈ SP যোগ কৰা হ'ল।",
copied: "কপি হ'ল", copy: "কপি কৰক", claim_ph: "এই ডিচলাইক কিয় ভুল?", claim_ok: "দাবী এডমিনলৈ পঠোৱা হ'ল", h_buy: "Pi ৰে কিনা (টেষ্ট)", h_tip: "টিপ পঠালে:", h_reward: "পুৰস্কাৰ", h_send: "পঠালে:",
lim_dis: "আজিৰ ডিচলাইক সীমা শেষ হ'ল।", hold_tip: "প্ৰোফাইল চাবলৈ নামত টিপক। অধিক বিকল্পৰ বাবে হেঁচি ধৰি ৰাখক।"
});
Object.assign(window.PS_I18N.zh, {
tag: "Pi 社区应用", signin_title: "使用 Pi 登录", need_pi: "请使用 Pi 登录后继续。本应用在 Pi Browser 中运行。", user_ph: "Pi 用户名", sound: "打开声音",
p_sub: "提交此表单后才能使用聊天、会议、动态和奖励。", gmail: "Gmail 邮箱", vis: "资料可见范围", pub: "公开 · 可获得 SP", priv: "私密 · 无 SP",
warn: "资料填写不实将无法获得 Sphere 积分 (SP)。请填写真实信息。", confirm: "我确认以上信息属实",
e_req: "请填写所有项目并勾选确认框。", e_mail: "请输入有效的 Gmail 地址。", e_mob: "请输入有效的手机号码。", e_pic: "无法使用这张图片，请换一张。",
name_ph: "名称", summary: "AI 聊天摘要", soon: "此功能将在下一阶段接入。", empty: "这里还没有内容", ch_only: "只有频道所有者可以发帖。",
m_create: "创建会议群组", m_join: "加入直播会议", m_id: "输入会议 ID", m_yours: "你的会议群组", m_rule: "会议中每 5 人，主持人可获得 1 SP。", m_id_lbl: "会议 ID",
like_rule: "每 100 个赞，作者获得 1 SP", ad: "本地广告", ad_default: "本地广告将显示在这里", pinned: "已置顶", hold: "长按可发送或接收",
buy_note: "款项从你的 Pi Wallet 支付。SP 不能换回 Pi，购买后不予退款。", watch: "看广告赚 SP", no_hist: "暂无记录", admin: "管理面板",
tip_to: "打赏给", amt: "SP 数量", e_amt: "请输入不超过余额的数量。", tip_ok: "打赏已发送", recv_note: "把你的 Pi 用户名告诉对方即可接收 SP：",
pubb: "公开", privb: "私密", priv_note: "此资料为私密。", contact: "联系电话", email: "邮箱", test_credit: "测试模式：未付款已添加 SP。",
copied: "已复制", copy: "复制", claim_ph: "为什么这个踩不合理？", claim_ok: "申诉已发送给管理员", h_buy: "用 Pi 购买（测试）", h_tip: "打赏给", h_reward: "奖励", h_send: "发送给",
lim_dis: "今天的踩次数已用完。", hold_tip: "点按名字查看资料，长按显示更多选项。"
});
Object.assign(window.PS_I18N.ja, {
tag: "Pi コミュニティアプリ", signin_title: "Pi でサインイン", need_pi: "続けるには Pi でサインインしてください。このアプリは Pi Browser 内で動作します。", user_ph: "Pi ユーザー名", sound: "音声をオン",
p_sub: "このフォームを送信すると、チャット、会議、フィード、リワードが使えるようになります。", gmail: "Gmail", vis: "プロフィールの公開範囲", pub: "公開 · SP 獲得可", priv: "非公開 · SP なし",
warn: "プロフィールに誤りがあると Sphere ポイント (SP) を受け取れません。正しい情報を入力してください。", confirm: "入力内容が正しいことを確認しました",
e_req: "すべての項目を入力し、チェックを入れてください。", e_mail: "有効な Gmail アドレスを入力してください。", e_mob: "有効な携帯電話番号を入力してください。", e_pic: "この画像は使用できませんでした。別の写真を選んでください。",
name_ph: "名前", summary: "AI チャット要約", soon: "この機能は次の段階で追加されます。", empty: "まだ何もありません", ch_only: "チャンネルに投稿できるのはオーナーのみです。",
m_create: "会議グループを作成", m_join: "ライブ会議に参加", m_id: "会議 ID を入力", m_yours: "あなたの会議グループ", m_rule: "会議の参加者 5 人ごとに、ホストは 1 SP を獲得します。", m_id_lbl: "会議 ID",
like_rule: "いいね 100 件で投稿者に 1 SP", ad: "ローカル広告", ad_default: "ローカル広告がここに表示されます", pinned: "ピン留め済み", hold: "長押しで送信または受け取り",
buy_note: "お支払いは Pi Wallet から行われます。SP を Pi に戻すことはできず、購入後の返金はありません。", watch: "広告を見て SP を獲得", no_hist: "まだ履歴がありません", admin: "管理パネル",
tip_to: "チップの送信先:", amt: "SP の数量", e_amt: "残高以内の数量を入力してください。", tip_ok: "チップを送信しました", recv_note: "SP を受け取るには Pi ユーザー名を伝えてください:",
pubb: "公開", privb: "非公開", priv_note: "このプロフィールは非公開です。", contact: "連絡先番号", email: "メール", test_credit: "テストモード: 支払いなしで SP を追加しました。",
copied: "コピーしました", copy: "コピー", claim_ph: "この低評価が不当な理由は？", claim_ok: "申し立てを管理者に送信しました", h_buy: "Pi で購入（テスト）", h_tip: "チップ送信:", h_reward: "リワード", h_send: "送信:",
lim_dis: "本日の低評価の上限に達しました。", hold_tip: "名前をタップするとプロフィールを表示します。長押しでその他の操作。"
});
Object.assign(window.PS_I18N.id, {
signin_title: "Masuk dengan Pi", need_pi: "Masuk dengan Pi untuk melanjutkan. Aplikasi ini berjalan di dalam Pi Browser.", user_ph: "Nama pengguna Pi",
p_sub: "Obrolan, rapat, beranda, dan hadiah terbuka setelah Anda mengirim formulir ini.", gmail: "Gmail",
warn: "Data profil yang salah membuat Anda tidak menerima Sphere Points (SP). Isi data asli Anda.",
e_req: "Isi semua kolom dan centang kotaknya.", e_mail: "Masukkan alamat Gmail yang valid.", e_mob: "Masukkan nomor ponsel yang valid.", e_pic: "Gambar ini tidak bisa dipakai. Coba foto lain.",
name_ph: "Nama", summary: "Ringkasan obrolan AI", soon: "Fitur ini tersambung di tahap berikutnya.", empty: "Belum ada apa-apa di sini", ch_only: "Hanya pemilik yang bisa memposting di kanal.",
m_create: "Buat grup rapat", m_join: "Gabung rapat langsung", m_id: "Masukkan ID rapat", m_yours: "Grup rapat Anda", m_rule: "Setiap 5 orang dalam rapat memberi tuan rumah 1 SP.", m_id_lbl: "ID rapat",
like_rule: "100 suka memberi penulis 1 SP", ad: "IKLAN LOKAL", ad_default: "Iklan lokal tampil di sini", pinned: "Disematkan", hold: "Tekan dan tahan untuk mengirim atau menerima",
buy_note: "Pembayaran diambil dari Pi Wallet Anda. SP tidak bisa ditukar kembali ke Pi dan pembelian tidak dapat dikembalikan.", watch: "Tonton iklan, dapat SP", no_hist: "Belum ada aktivitas", admin: "Panel admin",
tip_to: "Kirim tip ke", amt: "Jumlah SP", e_amt: "Masukkan jumlah yang Anda miliki.", tip_ok: "Tip terkirim", recv_note: "Bagikan nama pengguna Pi Anda untuk menerima SP:",
pubb: "PUBLIK", privb: "PRIVAT", priv_note: "Profil ini privat.", contact: "Nomor kontak", email: "Email", test_credit: "Mode uji: SP ditambahkan tanpa pembayaran.",
copied: "Disalin", copy: "Salin", claim_ph: "Mengapa tidak suka ini keliru?", claim_ok: "Klaim dikirim ke admin", h_buy: "Dibeli dengan Pi (uji)", h_tip: "Tip dikirim ke", h_reward: "Hadiah", h_send: "Dikirim ke",
lim_dis: "Batas tidak suka harian tercapai.", hold_tip: "Ketuk nama untuk melihat profil. Tekan dan tahan untuk opsi lain."
});
