/* PiSphere app, stage 1. Runs fully on the device with test data.
   Stage 2 swaps the "store" for the server (Supabase), Pi payments and LiveKit meetings. */
(function () {
"use strict";
var C = window.PS_CONFIG, R = window.PS_RULES, L = window.PS_I18N;
var KEY = "pisphere_v1";
var root = document.getElementById("root");

/* ---------- storage ---------- */
function seed() {
  var now = Date.now();
  return {
    lang: null, promoSeen: false, user: null, sp: 0, hist: [], msgCount: 0, chatPaid: 0,
    rooms: [
      { id: "r1", type: "group", name: "Global Pioneers Hub", owner: "PiSphere", members: 1, pinned: true, msgs: [] },
      { id: "r2", type: "group", name: "Local Business Network", owner: "PiSphere", members: 1, pinned: false, msgs: [] },
      { id: "r3", type: "channel", name: "PiSphere Updates", owner: "PiSphere", members: 1, pinned: false,
        msgs: [{ id: "m1", by: "PiSphere", text: "Welcome. This channel carries app updates.", ts: now, likes: [], dislikes: [] }] }
    ],
    posts: [{ id: "p1", by: "PiSphere", text: "PiSphere is in test mode. Post, like, tip and tell us what breaks.", ts: now, likes: [], dislikes: [], pinned: false, paid: 0, voided: 0 }],
    meets: [], ads: [], claims: [], rules: {}, ticker: null,
    rewardDay: { d: "", n: 0 }, disDay: { d: "", n: 0 }, claimWeek: { d: "", n: 0 }, once: {}
  };
}
var S;
function load() {
  try { var raw = localStorage.getItem(KEY); if (raw) { S = Object.assign(seed(), JSON.parse(raw)); return; } } catch (e) {}
  S = seed();
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
function rules() { return Object.assign({}, C.rules, S.rules); }
function ticker() { return Object.assign({}, C.ticker, S.ticker || {}); }

/* ---------- helpers ---------- */
var ui = { view: "promo", tab: "chats", sub: "dm", room: null, sheet: null, admin: false, editing: false, err: "" };
function t(k) { var d = L[S.lang] || {}; return d[k] != null ? d[k] : (L.en[k] != null ? L.en[k] : k); }
function today() { return new Date().toISOString().slice(0, 10); }
function uid(p) { return p + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36); }
function me() { return S.user ? S.user.username : ""; }
function isPublic() { return !!(S.user && S.user.profile && S.user.profile.pub); }
function isAdmin() { return me().toLowerCase() === C.adminUsername.toLowerCase(); }
function clean(s, n) { return String(s == null ? "" : s).replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, n || 200); }
function cleanUser(s) { return String(s || "").replace(/^@+/, "").replace(/[^A-Za-z0-9_.]/g, "").slice(0, 30); }
function maskPhone(p) { p = String(p || ""); return p.length < 5 ? "••••" : p.slice(0, 2) + "••••••" + p.slice(-2); }
function maskMail(m) { var a = String(m || "").split("@"); return a.length < 2 ? "••••" : a[0].slice(0, 2) + "••••@" + a[1]; }
function initials(n) { return (String(n || "?").replace(/[^A-Za-z0-9]/g, "").slice(0, 2) || "?").toUpperCase(); }

function h(tag, props) {
  var el = document.createElement(tag), i, k;
  props = props || {};
  for (k in props) {
    if (props[k] == null || props[k] === false) continue;
    if (k === "class") el.className = props[k];
    else if (k === "text") el.textContent = props[k];
    else if (k.slice(0, 2) === "on") el.addEventListener(k.slice(2), props[k]);
    else if (k === "value") el.value = props[k];
    else if (k === "checked" || k === "disabled" || k === "muted" || k === "autoplay" || k === "playsInline") el[k] = !!props[k];
    else el.setAttribute(k, props[k] === true ? "" : props[k]);
  }
  for (i = 2; i < arguments.length; i++) add(el, arguments[i]);
  return el;
}
function add(el, c) {
  if (c == null || c === false) return;
  if (Array.isArray(c)) { c.forEach(function (x) { add(el, x); }); return; }
  el.appendChild(typeof c === "string" || typeof c === "number" ? document.createTextNode(String(c)) : c);
}
var ICON = {
  chat: "M4 5h16v11H9l-5 4z", meet: "M3 7h12v10H3zM15 10l6-3v10l-6-3", feed: "M4 5h16v14H4zM8 9h8M8 13h8",
  gift: "M4 11h16v9H4zM3 7h18v4H3zM12 7v13M12 7c-2-4-6-3-5 0M12 7c2-4 6-3 5 0",
  globe: "M12 3a9 9 0 1 0 0 18a9 9 0 0 0 0-18M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18",
  gear: "M12 9a3 3 0 1 0 0 6a3 3 0 0 0 0-6M12 3v3M12 18v3M3 12h3M18 12h3M5.600 5.600l2.100 2.100M16.300 16.300l2.100 2.100M5.600 18.400l2.100-2.100M16.300 7.700l2.100-2.100",
  up: "M7 11v9H4v-9zM7 11l4-7c1.500 0 2.500 1 2.500 2.500V10h5a2 2 0 0 1 2 2.300l-1 6a2 2 0 0 1-2 1.700H7",
  down: "M7 13V4H4v9zM7 13l4 7c1.500 0 2.500-1 2.500-2.500V14h5a2 2 0 0 0 2-2.300l-1-6A2 2 0 0 0 17.500 4H7",
  share: "M14 5l6 6-6 6M20 11H9a5 5 0 0 0-5 5v3", pin: "M9 4h6l-1 6 3 3H7l3-3zM12 13v7", unpin: "M9 4h6l-1 6 3 3H7l3-3zM12 13v7M4 4l16 16",
  trash: "M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13", plus: "M12 5v14M5 12h14", back: "M15 5l-7 7 7 7",
  tip: "M12 4a8 8 0 1 0 0 16a8 8 0 0 0 0-16M12 8v8M9 11l3-3 3 3", cam: "M4 8h3l2-3h6l2 3h3v11H4zM12 10a3.500 3.500 0 1 0 0 7a3.500 3.500 0 0 0 0-7",
  play: "M4 5h16v14H4zM10 9l5 3-5 3z", list: "M5 6h14M5 12h14M5 18h8", flag: "M5 21V4h12l-2 4 2 4H5"
};
function ic(name, size) {
  var ns = "http://www.w3.org/2000/svg", s = document.createElementNS(ns, "svg"), p = document.createElementNS(ns, "path");
  s.setAttribute("viewBox", "0 0 24 24"); s.setAttribute("width", size || 20); s.setAttribute("height", size || 20);
  s.setAttribute("fill", "none"); s.setAttribute("stroke", "currentColor"); s.setAttribute("stroke-width", "1.8");
  s.setAttribute("stroke-linecap", "round"); s.setAttribute("stroke-linejoin", "round"); s.setAttribute("aria-hidden", "true");
  p.setAttribute("d", ICON[name]); s.appendChild(p); return s;
}
function toast(msg) {
  var old = document.querySelector(".toast"); if (old) old.remove();
  var el = h("div", { class: "toast", role: "status", text: msg });
  document.body.appendChild(el); setTimeout(function () { el.remove(); }, 2400);
}
/* press and hold; also right-click on a computer */
function hold(el, fn) {
  var timer = null, x = 0, y = 0;
  function stop() { if (timer) { clearTimeout(timer); timer = null; } }
  el.addEventListener("pointerdown", function (e) {
    x = e.clientX; y = e.clientY; stop();
    timer = setTimeout(function () { timer = null; el._held = true; fn(); }, 550);
  });
  el.addEventListener("pointermove", function (e) { if (Math.abs(e.clientX - x) > 10 || Math.abs(e.clientY - y) > 10) stop(); });
  ["pointerup", "pointerleave", "pointercancel"].forEach(function (n) { el.addEventListener(n, stop); });
  el.addEventListener("click", function (e) { if (el._held) { el._held = false; e.stopImmediatePropagation(); e.preventDefault(); } }, true);
  el.addEventListener("contextmenu", function (e) { e.preventDefault(); stop(); fn(); });
  return el;
}
function avatar(name, pic, cls) {
  return h("span", { class: "avatar " + (cls || "sm"), "aria-hidden": "true" }, pic ? h("img", { src: pic, alt: "" }) : initials(name));
}
function picOf(username) { return username === me() && S.user.profile ? S.user.profile.pic : null; }

/* ---------- SP ---------- */
function credit(amount, key, extra) { S.sp += amount; S.hist.unshift({ t: Date.now(), k: key, x: extra || "", a: amount }); S.hist = S.hist.slice(0, 200); }
function rewardCredit(amount, extra) {
  if (!isPublic() || amount <= 0) return 0;
  if (S.rewardDay.d !== today()) S.rewardDay = { d: today(), n: 0 };
  var grant = Math.min(amount, rules().dailyRewardCap - S.rewardDay.n);
  if (grant <= 0) return 0;
  S.rewardDay.n += grant; credit(grant, "h_reward", extra); return grant;
}
function postReward(p) {
  if (p.by !== me()) return;
  var earned = R.feed(p.likes.length, Math.max(0, p.dislikes.length - (p.voided || 0)), rules());
  var delta = earned - (p.paid || 0);
  if (delta > 0) p.paid = (p.paid || 0) + rewardCredit(delta, "· " + rules().likesPerSp + " likes");
}
function chatReward() {
  var earned = R.chat(S.msgCount, rules()), delta = earned - (S.chatPaid || 0);
  if (delta > 0) S.chatPaid = (S.chatPaid || 0) + rewardCredit(delta, "· chat");
}
function roomReward(room) {
  if (room.owner !== me() || room.type === "dm") return;
  var day = Date.now() - 864e5, n = room.msgs.filter(function (m) { return m.ts > day; }).length;
  var amount = room.type === "group" ? R.group(room.members, n, rules(), C.groupTable) : R.channel(room.members, n, rules());
  var k = room.id + ":" + today();
  if (amount > 0 && !S.once[k]) { S.once[k] = 1; rewardCredit(amount, "· " + room.name); }
}

/* ---------- ads ---------- */
function activeAds(place) {
  var d = today(), city = S.user && S.user.profile ? S.user.profile.city.toLowerCase() : "";
  return S.ads.filter(function (a) {
    return a.places[place] && (!a.from || a.from <= d) && (!a.to || a.to >= d) && (!a.city || a.city.toLowerCase() === city);
  });
}
function adCard(a) {
  return h("article", { class: "card ad" },
    h("span", { class: "tag", style: "align-self:flex-start", text: t("sponsored").toUpperCase() }),
    h("b", { text: a.title }), a.text ? h("p", { class: "txt", text: a.text }) : null,
    a.link ? h("span", { class: "sub", text: a.link }) : null);
}

/* ---------- targets for the hold menu ---------- */
function findTarget(tg) {
  if (tg.kind === "post") return S.posts.filter(function (p) { return p.id === tg.id; })[0];
  if (tg.kind === "room") return S.rooms.filter(function (r) { return r.id === tg.id; })[0];
  if (tg.kind === "meet") return S.meets.filter(function (m) { return m.id === tg.id; })[0];
  if (tg.kind === "msg") { var r = S.rooms.filter(function (x) { return x.id === tg.room; })[0]; return r ? r.msgs.filter(function (m) { return m.id === tg.id; })[0] : null; }
  return null;
}
function ownerOf(tg, o) { return tg.kind === "room" || tg.kind === "meet" ? o.owner : o.by; }
function vote(tg, up) {
  var o = findTarget(tg); if (!o || !o.likes) return;
  var u = me(), li = o.likes.indexOf(u), di = o.dislikes.indexOf(u);
  if (up) { if (li >= 0) o.likes.splice(li, 1); else { o.likes.push(u); if (di >= 0) o.dislikes.splice(di, 1); } }
  else {
    if (di >= 0) o.dislikes.splice(di, 1);
    else {
      if (!isPublic()) { toast(t("priv") ); return; }
      if (S.disDay.d !== today()) S.disDay = { d: today(), n: 0 };
      if (S.disDay.n >= rules().dailyDislikeLimit) { toast(t("lim_dis")); return; }
      S.disDay.n++; o.dislikes.push(u); if (li >= 0) o.likes.splice(li, 1);
    }
  }
  if (tg.kind === "post") postReward(o);
  save(); render();
}
function setPin(tg, v) { var o = findTarget(tg); if (o) { o.pinned = v; save(); } ui.sheet = null; render(); }
function canDelete(tg, o) { return isAdmin() || ownerOf(tg, o) === me(); }
function removeTarget(tg) {
  if (tg.kind === "post") S.posts = S.posts.filter(function (p) { return p.id !== tg.id; });
  if (tg.kind === "room") { S.rooms = S.rooms.filter(function (r) { return r.id !== tg.id; }); if (ui.room === tg.id) ui.room = null; }
  if (tg.kind === "meet") S.meets = S.meets.filter(function (m) { return m.id !== tg.id; });
  if (tg.kind === "msg") { var r = S.rooms.filter(function (x) { return x.id === tg.room; })[0]; if (r) r.msgs = r.msgs.filter(function (m) { return m.id !== tg.id; }); }
  save(); ui.sheet = null; render();
}

/* ---------- sheets ---------- */
function openSheet(s) { ui.sheet = s; ui.err = ""; render(); }
function closeSheet() { ui.sheet = null; ui.err = ""; render(); }
function sheetView() {
  var s = ui.sheet, body;
  if (s.type === "menu") body = menuSheet(s.target);
  else if (s.type === "card") body = cardSheet(s.username);
  else if (s.type === "tip") body = tipSheet(s.to, "h_tip");
  else if (s.type === "send") body = tipSheet("", "h_send");
  else if (s.type === "receive") body = [h("p", { class: "sub", text: t("recv_note") }), h("p", { class: "h1", text: "@" + me() }),
    h("button", { class: "btn flat", onclick: function () { try { navigator.clipboard.writeText("@" + me()).then(function () { toast(t("copied")); }, function () {}); } catch (e) {} }, text: t("copy") })];
  else if (s.type === "hold-bal") body = h("div", { class: "row2" },
    h("button", { class: "btn pri", onclick: function () { openSheet({ type: "send" }); }, text: t("send") }),
    h("button", { class: "btn flat", onclick: function () { openSheet({ type: "receive" }); }, text: t("receive") }));
  else if (s.type === "lang") body = h("div", { class: "langs" }, C.languages.map(function (l) {
    return h("button", { class: "btn " + (S.lang === l[0] ? "pri" : "flat"), lang: l[0], onclick: function () { S.lang = l[0]; save(); document.documentElement.lang = l[0]; closeSheet(); }, text: l[1] });
  }));
  else if (s.type === "new") body = newSheet(s.kind);
  else if (s.type === "claim") body = claimSheet(s.target);
  else if (s.type === "settings") body = [
    h("button", { class: "btn flat", onclick: function () { ui.sheet = null; ui.editing = true; ui.view = "profile"; render(); }, text: t("edit") }),
    h("button", { class: "btn flat", onclick: function () { openSheet({ type: "lang" }); } }, ic("globe"), t("lang")),
    isAdmin() ? h("button", { class: "btn pri", onclick: function () { ui.sheet = null; ui.admin = true; render(); }, text: t("admin") }) : null];
  else if (s.type === "reset") body = [h("p", { class: "note warn", text: t("a_reset_q") }),
    h("button", { class: "btn danger", onclick: resetData, text: t("a_yes") })];
  return h("div", { class: "veil", onclick: function (e) { if (e.target === e.currentTarget) closeSheet(); } },
    h("section", { class: "sheet", role: "dialog", "aria-modal": "true" }, body,
      ui.err ? h("p", { class: "note err", role: "alert", text: ui.err }) : null,
      h("button", { class: "btn flat", onclick: closeSheet, text: t("close") })));
}
function menuSheet(tg) {
  var o = findTarget(tg); if (!o) return h("p", { class: "sub", text: t("empty") });
  var owner = ownerOf(tg, o), pins = tg.kind !== "msg", inDm = false;
  if (tg.kind === "msg") { var rm = S.rooms.filter(function (x) { return x.id === tg.room; })[0]; inDm = !!rm && rm.type === "dm"; }
  var votes = !!o.likes && !inDm;
  function mb(icon, label, fn, on, cls) { return h("button", { class: "btn " + (cls || ""), disabled: !on, onclick: fn }, ic(icon, 18), label); }
  return [
    h("div", { class: "who" }, avatar(owner, picOf(owner)), h("b", { text: "@" + owner })),
    h("div", { class: "menu" },
      mb("up", t("like"), function () { ui.sheet = null; vote(tg, true); }, votes),
      mb("down", t("dislike"), function () { ui.sheet = null; vote(tg, false); }, votes && owner !== me()),
      mb("tip", t("tip"), function () { openSheet({ type: "tip", to: owner }); }, owner !== me(), "pri"),
      mb("pin", t("pin"), function () { setPin(tg, true); }, pins && !o.pinned),
      mb("unpin", t("unpin"), function () { setPin(tg, false); }, pins && !!o.pinned),
      mb("trash", t("del"), function () { removeTarget(tg); }, canDelete(tg, o))),
    votes && owner === me() && o.dislikes.length > (o.voided || 0)
      ? h("button", { class: "btn flat", onclick: function () { openSheet({ type: "claim", target: tg }); } }, ic("flag", 18), t("claim")) : null
  ];
}
function cardSheet(username) {
  var mine = username === me(), p = mine ? S.user.profile : null, rows;
  if (p && (mine || p.pub)) rows = h("div", { class: "kv" },
    h("div", {}, h("span", { text: t("contact") }), h("span", { text: mine ? p.mobile : maskPhone(p.mobile) })),
    h("div", {}, h("span", { text: t("email") }), h("span", { text: mine ? p.email : maskMail(p.email) })),
    h("div", {}, h("span", { text: t("country") }), h("span", { text: p.country })),
    h("div", {}, h("span", { text: t("state") + ", " + t("city") }), h("span", { text: p.state + ", " + p.city })));
  else rows = h("p", { class: "note info", text: mine ? t("priv_note") : t("soon") });
  return [
    h("div", { class: "who" }, avatar(username, picOf(username), "lg"),
      h("span", { class: "grow" }, h("b", { text: p ? p.name : "@" + username }), h("span", { class: "sub", text: "@" + username })),
      p ? h("span", { class: "tag" + (p.pub ? " live" : ""), text: p.pub ? t("pubb") : t("privb") }) : null),
    rows,
    mine ? null : h("button", { class: "btn pri", onclick: function () { openSheet({ type: "tip", to: username }); } }, ic("tip", 18), t("tip"))
  ];
}
function tipSheet(to, key) {
  var user = h("input", { type: "text", id: "tp-user", placeholder: t("user_ph"), value: to, maxlength: "31", autocomplete: "off" });
  var amt = h("input", { type: "number", id: "tp-amt", placeholder: t("amt"), min: "1", step: "1", inputmode: "numeric" });
  function go() {
    var u = cleanUser(user.value), n = Math.floor(Number(amt.value));
    if (!u || u.toLowerCase() === me().toLowerCase() || !(n > 0) || n > S.sp) { ui.err = t("e_amt"); render(); return; }
    credit(-n, key, "@" + u); save(); ui.sheet = null; ui.err = ""; render(); toast(t("tip_ok"));
  }
  return [h("b", { text: to ? t("tip_to") + " @" + to : t("send") }),
    to ? null : h("div", { class: "field" }, h("label", { for: "tp-user", text: t("user_ph") }), user),
    h("div", { class: "field" }, h("label", { for: "tp-amt", text: t("amt") + " (" + S.sp + " SP)" }), amt),
    h("button", { class: "btn pri", onclick: go, text: t("send") })];
}
function newSheet(kind) {
  var label = kind === "dm" ? t("user_ph") : t("name_ph");
  var inp = h("input", { type: "text", id: "nw-name", placeholder: label, maxlength: "40", autocomplete: "off" });
  function go() {
    var v = kind === "dm" ? cleanUser(inp.value) : clean(inp.value, 40);
    if (!v || (kind === "dm" && v.toLowerCase() === me().toLowerCase())) return;
    if (kind === "meet") S.meets.unshift({ id: String(Math.floor(100000 + Math.random() * 900000)), name: v, owner: me(), pinned: false });
    else S.rooms.unshift({ id: uid("r"), type: kind, name: kind === "dm" ? "@" + v : v, peer: kind === "dm" ? v : null, owner: me(), members: 1, pinned: false, msgs: [] });
    save(); closeSheet();
  }
  var title = { dm: "new_chat", group: "new_group", channel: "new_channel", meet: "m_create" }[kind];
  return [h("b", { text: t(title) }), h("div", { class: "field" }, h("label", { for: "nw-name", text: label }), inp),
    h("button", { class: "btn pri", onclick: go, text: t("create") })];
}
function claimSheet(tg) {
  var ta = h("textarea", { id: "cl-text", placeholder: t("claim_ph"), maxlength: "300" });
  function go() {
    var txt = clean(ta.value, 300); if (!txt) return;
    var wk = today().slice(0, 8) + Math.floor(new Date().getDate() / 7);
    if (S.claimWeek.d !== wk) S.claimWeek = { d: wk, n: 0 };
    if (S.claimWeek.n >= rules().weeklyClaimLimit) { ui.err = t("lim_dis"); render(); return; }
    S.claimWeek.n++; S.claims.unshift({ id: uid("c"), target: tg, by: me(), text: txt, ts: Date.now(), status: "open" });
    save(); ui.sheet = null; render(); toast(t("claim_ok"));
  }
  return [h("b", { text: t("claim") }), h("label", { class: "sr", for: "cl-text", text: t("claim_ph") }), ta,
    h("button", { class: "btn pri", onclick: go, text: t("send") })];
}

/* ---------- promo, sign-in, profile ---------- */
function afterPromo() {
  S.promoSeen = true; save();
  ui.view = !S.user ? "signin" : (!S.user.profile ? "profile" : "app"); render();
}
function promoView() {
  var skip = h("button", { class: "btn flat sm", onclick: afterPromo, text: t("skip") });
  var v = h("video", { src: "assets/promo.mp4", autoplay: true, playsInline: true, playsinline: true, "aria-label": "PiSphere promo" });
  v.addEventListener("ended", afterPromo);
  v.addEventListener("error", function () { skip.textContent = t("cont"); });
  /* Phones refuse to start sound before the first touch. If that happens, play silently and switch the sound on at the first touch. */
  function unmute() { v.muted = false; if (v.paused) { var q = v.play(); if (q && q.catch) q.catch(function () {}); } }
  setTimeout(function () {
    v.muted = false;
    var p = v.play();
    if (p && p.catch) p.catch(function () {
      v.muted = true; var q = v.play(); if (q && q.catch) q.catch(function () { skip.textContent = t("cont"); });
      v.addEventListener("pointerdown", unmute, { once: true });
      document.addEventListener("pointerdown", function once() { document.removeEventListener("pointerdown", once); if (ui.view === "promo") unmute(); });
    });
  }, 0);
  return h("div", { class: "promo" }, v, h("div", { class: "promo-bar" }, skip), footer(true));
}
function setUser(name) { S.user = { username: name, profile: null }; save(); ui.view = "profile"; render(); }
function piGo() {
  if (!window.Pi) { toast(t("need_pi")); return; }
  try {
    if (!piGo.ready) { window.Pi.init({ version: "2.0", sandbox: !!C.piSandbox }); piGo.ready = true; }
    window.Pi.authenticate(["username"], function () {}).then(function (a) {
      var u = cleanUser(a && a.user && a.user.username);
      if (u) { S.piUid = a.user.uid || ""; setUser(u); } else toast(t("need_pi"));
    }, function () { toast(t("need_pi")); });
  } catch (e) { toast(t("need_pi")); }
}
function signinView() {
  var kids = [h("h1", { class: "h1", text: t("signin_title") }), h("p", { class: "sub", text: t("need_pi") }),
    h("button", { class: "btn pi", onclick: piGo, text: t("signin") })];
  if (!window.Pi) {
    var inp = h("input", { type: "text", id: "si-user", placeholder: t("user_ph"), maxlength: "31", autocomplete: "off" });
    kids.push(h("div", { class: "card" }, h("p", { class: "note info", text: t("prev") }),
      h("div", { class: "field" }, h("label", { for: "si-user", text: t("user_ph") }), inp),
      h("button", { class: "btn flat", onclick: function () { var u = cleanUser(inp.value); if (u) setUser(u); }, text: t("cont") })));
  }
  return h("main", { class: "main" }, h("div", { class: "center" }, kids));
}
function shrink(file, done) {
  if (!file || (file.type && file.type.indexOf("image/") !== 0) || file.size > 3e7) { done(null); return; }
  var fr = new FileReader();
  fr.onload = function () {
    var img = new Image();
    img.onload = function () {
      var c = document.createElement("canvas"), s = Math.min(img.width, img.height); c.width = c.height = 160;
      c.getContext("2d").drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 160, 160);
      done(c.toDataURL("image/jpeg", 0.72));
    };
    img.onerror = function () { done(null); }; img.src = fr.result;
  };
  fr.onerror = function () { done(null); }; fr.readAsDataURL(file);
}
function profileView() {
  var p = (S.user && S.user.profile) || { name: "", mobile: "", email: "", country: "", state: "", city: "", pic: null, pub: true };
  var draft = { pic: p.pic, pub: p.pub !== false };
  function field(id, label, type, val, max) {
    return h("div", { class: "field" }, h("label", { for: id, text: label }), h("input", { type: type, id: id, value: val, maxlength: String(max), autocomplete: "off" }));
  }
  var pic = avatar(S.user.username, draft.pic, "lg");
  var file = h("input", { type: "file", id: "pf-file", accept: "image/*", class: "sr", onchange: function () {
    shrink(file.files[0], function (d) { if (d) { draft.pic = d; pic.replaceChildren(h("img", { src: d, alt: "" })); } else toast(t("e_pic")); });
  } });
  var pubB = h("button", { class: "btn", type: "button", onclick: function () { draft.pub = true; paint(); }, text: t("pub") });
  var privB = h("button", { class: "btn", type: "button", onclick: function () { draft.pub = false; paint(); }, text: t("priv") });
  function paint() {
    pubB.className = "btn " + (draft.pub ? "pri" : "flat"); privB.className = "btn " + (draft.pub ? "flat" : "pri");
    pubB.setAttribute("aria-pressed", String(draft.pub)); privB.setAttribute("aria-pressed", String(!draft.pub));
  }
  paint();
  var agree = h("input", { type: "checkbox", id: "pf-ok" });
  var err = h("p", { class: "note err", role: "alert" }); err.hidden = true;
  function val(id) { return document.getElementById(id).value; }
  function submit(e) {
    e.preventDefault();
    var d = { name: clean(val("pf-name"), 60), mobile: val("pf-mobile").replace(/[^\d+]/g, "").slice(0, 16), email: clean(val("pf-mail"), 80).toLowerCase(),
      country: clean(val("pf-country"), 40), state: clean(val("pf-state"), 40), city: clean(val("pf-city"), 40), pic: draft.pic, pub: draft.pub };
    var msg = "";
    if (!d.name || !d.mobile || !d.email || !d.country || !d.state || !d.city || !agree.checked) msg = t("e_req");
    else if (!/^\+?\d{7,15}$/.test(d.mobile)) msg = t("e_mob");
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.email)) msg = t("e_mail");
    if (msg) { err.textContent = msg; err.hidden = false; return; }
    S.user.profile = d; save(); ui.editing = false; ui.view = "app"; render();
  }
  return h("form", { class: "main", novalidate: true, onsubmit: submit },
    h("div", { class: "brand" }, h("img", { src: "assets/logo.png", alt: "" }), h("b", { text: C.appName })),
    h("h1", { class: "h1", text: ui.editing ? t("edit") : t("p_title") }),
    ui.editing ? null : h("p", { class: "sub", text: t("p_sub") }),
    h("div", { class: "card", style: "flex-direction:row;align-items:center" }, pic,
      h("div", { class: "field" }, h("span", { class: "lbl", text: t("photo") }),
        h("label", { class: "btn flat sm", for: "pf-file", text: t("upload") }), file)),
    field("pf-name", t("name"), "text", p.name, 60), field("pf-mobile", t("mobile"), "tel", p.mobile, 16), field("pf-mail", t("gmail"), "email", p.email, 80),
    field("pf-country", t("country"), "text", p.country, 40),
    h("div", { class: "row2" }, field("pf-state", t("state"), "text", p.state, 40), field("pf-city", t("city"), "text", p.city, 40)),
    h("span", { class: "lbl", text: t("vis") }), h("div", { class: "row2" }, pubB, privB),
    h("p", { class: "note warn", text: t("warn") }),
    h("label", { class: "chk", for: "pf-ok" }, agree, t("confirm")), err,
    h("button", { class: "btn pri", type: "submit", text: ui.editing ? t("save") : t("submit") }),
    ui.editing ? h("button", { class: "btn flat", type: "button", onclick: function () { ui.editing = false; ui.view = "app"; render(); }, text: t("cancel") }) : null,
    footer(true));
}

/* ---------- shell ---------- */
function footer(plain) { return h("footer", { class: "foot" + (plain ? " plain" : ""), text: C.copyright }); }
function header() {
  var signed = !!(S.user && S.user.profile);
  return h("header", { class: "hdr" },
    h("div", { class: "brand" }, h("img", { src: "assets/logo.png", alt: "" }), h("b", { text: C.appName })),
    h("div", { class: "hdr-r" },
      signed ? h("button", { class: "avatar", "aria-label": t("photo"), onclick: function () { openSheet({ type: "card", username: me() }); } },
        S.user.profile.pic ? h("img", { src: S.user.profile.pic, alt: "" }) : initials(me())) : null,
      h("button", { class: "pill", "aria-label": t("lang"), onclick: function () { openSheet({ type: "lang" }); } }, ic("globe", 16), S.lang.toUpperCase()),
      signed ? h("button", { class: "pill pi name", onclick: function () { openSheet({ type: "card", username: me() }); }, text: "@" + me() })
        : h("button", { class: "pill pi", onclick: piGo, text: t("signin") })));
}
var tickSig = "";
function updateTicker(show) {
  if (!show) { hosts.tick.replaceChildren(); tickSig = ""; return; }
  var ads = activeAds("ticker"), k = ticker();
  var text = ads.length ? ads.map(function (a) { return a.title + (a.text ? " \u00b7 " + a.text : "") + (a.link ? " \u00b7 " + a.link : ""); }).join("     \u2022     ") : t("ad_default");
  var speed = Math.min(200, Math.max(15, Number(k.speed) || 45));
  var sig = [text, k.bg, k.fg, speed, S.lang].join("|");
  if (sig === tickSig) return;
  tickSig = sig;
  function unit() { return h("span", { class: "tick-unit", text: text }); }
  var g1 = h("span", { class: "tick-grp" }, unit()), track = h("div", { class: "tick-track" }, g1), win = h("div", { class: "tick-win" }, track);
  track.style.color = k.fg;
  var box = h("div", { class: "ticker" }, h("span", { class: "tag", text: t("ad") }), win); box.style.background = k.bg;
  hosts.tick.replaceChildren(box);
  requestAnimationFrame(function () {
    var w = g1.offsetWidth, W = win.offsetWidth; if (!w || !W) return;
    for (var n = Math.ceil(W / w) + 1, i = 1; i < n; i++) g1.appendChild(unit());
    var g2 = g1.cloneNode(true); g2.setAttribute("aria-hidden", "true"); track.appendChild(g2);
    track.style.animationDuration = (g1.offsetWidth / speed).toFixed(2) + "s"; track.classList.add("go");
  });
}
function nav() {
  var tabs = [["chats", "chat", "n_chats"], ["meet", "meet", "n_meet"], ["feed", "feed", "n_feed"], ["rew", "gift", "n_rew"]];
  return h("nav", { class: "nav", "aria-label": "Main" }, tabs.map(function (x) {
    return h("button", { "aria-current": ui.tab === x[0] && !ui.admin ? "page" : null, onclick: function () { ui.tab = x[0]; ui.room = null; ui.admin = false; render(); } }, ic(x[1]), t(x[2]));
  }));
}
function whoBtn(username, sub, tg) {
  var b = h("button", { class: "who", onclick: function () { openSheet({ type: "card", username: username }); } },
    avatar(username, picOf(username)), h("span", { class: "grow" }, h("b", { text: "@" + username }), sub ? h("span", { class: "tiny", text: sub }) : null));
  return tg ? hold(b, function () { openSheet({ type: "menu", target: tg }); }) : b;
}
function byPin(a, b) { return (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0); }
function when(ts) { var d = new Date(ts); return d.toLocaleDateString(S.lang, { day: "numeric", month: "short" }) + " " + d.toLocaleTimeString(S.lang, { hour: "2-digit", minute: "2-digit" }); }

/* ---------- chats ---------- */
function chatsView() {
  var subs = [["dm", "t_chats"], ["group", "t_groups"], ["channel", "t_channels"]];
  var list = S.rooms.filter(function (r) { return r.type === ui.sub; }).sort(byPin);
  var newKey = { dm: "new_chat", group: "new_group", channel: "new_channel" }[ui.sub];
  return [
    h("div", { class: "seg" }, subs.map(function (x) { return h("button", { "aria-pressed": String(ui.sub === x[0]), onclick: function () { ui.sub = x[0]; render(); }, text: t(x[1]) }); })),
    activeAds("chats").map(adCard),
    list.length ? list.map(function (r) {
      var tg = { kind: "room", id: r.id };
      return hold(h("button", { class: "item", onclick: function () { ui.room = r.id; render(); } },
        avatar(r.name.replace(/^@/, "")),
        h("span", { class: "grow" }, h("b", { text: r.name }), h("span", { class: "sub", text: r.type === "dm" ? t("t_chats") : r.members + " " + t("members") })),
        r.pinned ? h("span", { role: "img", "aria-label": t("pinned"), style: "color:var(--mute);display:flex" }, ic("pin", 18)) : null),
        function () { openSheet({ type: "menu", target: tg }); });
    }) : h("p", { class: "sub", text: t("empty") }),
    h("p", { class: "tiny", text: t("hold_tip") }),
    h("button", { class: "btn pri", onclick: function () { openSheet({ type: "new", kind: ui.sub }); } }, ic("plus", 18), t(newKey)),
    h("button", { class: "btn", onclick: function () { toast(t("soon")); } }, ic("list", 18), t("summary"))
  ];
}
function roomView(r) {
  var canPost = r.type !== "channel" || r.owner === me();
  var inp = h("input", { type: "text", id: "rm-msg", placeholder: t("msg_ph"), maxlength: "1000", autocomplete: "off" });
  function send(e) {
    e.preventDefault(); var v = clean(inp.value, 1000); if (!v) return;
    r.msgs.push({ id: uid("m"), by: me(), text: v, ts: Date.now(), likes: [], dislikes: [] });
    if (r.type === "dm") { S.msgCount++; chatReward(); } else roomReward(r);
    save(); render();
    var box = document.querySelector(".main"); if (box) box.scrollTop = box.scrollHeight;
    var again = document.getElementById("rm-msg"); if (again) again.focus();
  }
  return [
    h("div", { class: "line", style: "align-items:center" },
      h("button", { class: "btn flat sm", "aria-label": t("back"), onclick: function () { ui.room = null; render(); } }, ic("back", 18)),
      h("div", { class: "grow", style: "flex:1;min-width:0" }, h("b", { text: r.name }), h("div", { class: "tiny", text: r.type === "dm" ? t("t_chats") : r.members + " " + t("members") })),
      r.type === "dm" ? h("button", { class: "btn pri sm", onclick: function () { openSheet({ type: "tip", to: r.peer }); }, text: t("tip") })
        : h("button", { class: "btn pri sm", disabled: r.owner === me(), onclick: function () { openSheet({ type: "tip", to: r.owner }); }, text: t("tip") })),
    h("div", { class: "msgs" }, r.msgs.length ? r.msgs.map(function (m) {
      var tg = { kind: "msg", room: r.id, id: m.id }, b = h("button", { class: "msg" + (m.by === me() ? " me" : ""), onclick: function () { openSheet({ type: "card", username: m.by }); } },
        h("small", { text: "@" + m.by + " · " + when(m.ts) + (r.type !== "dm" && (m.likes.length || m.dislikes.length) ? "  +" + m.likes.length + " / -" + m.dislikes.length : "") }), m.text);
      return hold(b, function () { openSheet({ type: "menu", target: tg }); });
    }) : h("p", { class: "sub", text: t("empty") })),
    canPost ? h("form", { class: "line", onsubmit: send }, h("label", { class: "sr", for: "rm-msg", text: t("msg_ph") }), inp, h("button", { class: "btn pri", type: "submit", text: t("send") }))
      : h("p", { class: "note info", text: t("ch_only") })
  ];
}

/* ---------- meetings ---------- */
function meetView() {
  var idIn = h("input", { type: "text", id: "mt-id", placeholder: t("m_id"), maxlength: "12", inputmode: "numeric", autocomplete: "off" });
  var r = rules();
  return [
    h("h1", { class: "h1", text: t("m_title") }),
    h("div", { class: "row2" },
      h("button", { class: "btn pri big", onclick: function () { openSheet({ type: "new", kind: "meet" }); } }, ic("plus", 24), t("m_create")),
      h("button", { class: "btn big", onclick: function () { idIn.focus(); } }, ic("meet", 24), t("m_join"))),
    h("form", { class: "line", onsubmit: function (e) { e.preventDefault(); toast(t("soon")); } }, h("label", { class: "sr", for: "mt-id", text: t("m_id") }), idIn, h("button", { class: "btn flat", type: "submit", text: t("join") })),
    activeAds("meet").map(adCard),
    h("h2", { class: "h2", text: t("m_yours") }),
    S.meets.length ? S.meets.slice().sort(byPin).map(function (m) {
      var tg = { kind: "meet", id: m.id };
      return hold(h("div", { class: "card" },
        h("div", { class: "line", style: "align-items:center;justify-content:space-between" },
          h("div", { style: "min-width:0" }, h("b", { text: m.name }), h("div", { class: "sub", text: t("m_id_lbl") + ": " + m.id + " · " + r.meetingMinutes + " min · " + r.meetingPeople })),
          m.pinned ? h("span", { role: "img", "aria-label": t("pinned"), style: "color:var(--mute);display:flex" }, ic("pin", 18)) : null),
        h("div", { class: "row2" },
          h("button", { class: "btn pri sm", onclick: function () { toast(t("soon")); }, text: t("start") }),
          h("button", { class: "btn flat sm", onclick: function () { openSheet({ type: "menu", target: tg }); }, text: "•••", "aria-label": t("pin") + ", " + t("del") }))),
        function () { openSheet({ type: "menu", target: tg }); });
    }) : h("p", { class: "sub", text: t("empty") }),
    h("p", { class: "note info", text: t("m_rule") })
  ];
}

/* ---------- feed ---------- */
function feedView() {
  var inp = h("input", { type: "text", id: "fd-new", placeholder: t("post_ph"), maxlength: "500", autocomplete: "off" });
  function post(e) {
    e.preventDefault(); var v = clean(inp.value, 500); if (!v) return;
    S.posts.unshift({ id: uid("p"), by: me(), text: v, ts: Date.now(), likes: [], dislikes: [], pinned: false, paid: 0, voided: 0 });
    save(); render();
  }
  var ads = activeAds("feed"), out = [
    h("form", { class: "line", onsubmit: post }, h("label", { class: "sr", for: "fd-new", text: t("post_ph") }), inp, h("button", { class: "btn pri", type: "submit", text: t("post") }))];
  S.posts.slice().sort(function (a, b) { return byPin(a, b) || b.ts - a.ts; }).forEach(function (p, i) {
    var tg = { kind: "post", id: p.id }, u = me();
    function ib(icon, label, n, on, fn) {
      return h("button", { class: "btn " + (on ? "pri" : "flat"), "aria-label": label, "aria-pressed": String(!!on), onclick: fn }, ic(icon, 18), n == null ? null : h("span", { text: String(n) }));
    }
    out.push(h("article", { class: "card" },
      h("div", { class: "line", style: "justify-content:space-between;align-items:center" }, whoBtn(p.by, when(p.ts), tg),
        p.pinned ? h("span", { role: "img", "aria-label": t("pinned"), style: "color:var(--mute);display:flex" }, ic("pin", 18)) : null),
      h("p", { class: "txt", text: p.text }),
      h("div", { class: "acts", style: "grid-template-columns:repeat(4,minmax(0,1fr))" },
        ib("up", t("like"), p.likes.length, p.likes.indexOf(u) >= 0, function () { vote(tg, true); }),
        ib("down", t("dislike"), p.dislikes.length, p.dislikes.indexOf(u) >= 0, function () { if (p.by === u) return; vote(tg, false); }),
        ib("share", t("share"), null, false, function () { try { navigator.clipboard.writeText(p.text).then(function () { toast(t("copied")); }, function () {}); } catch (e) {} }),
        h("button", { class: "btn flat", disabled: p.by === u, onclick: function () { openSheet({ type: "tip", to: p.by }); }, text: t("tip") })),
      h("span", { class: "tiny", text: t("like_rule") })));
    if (i === 0) ads.forEach(function (a) { out.push(adCard(a)); });
  });
  if (!S.posts.length) ads.forEach(function (a) { out.push(adCard(a)); });
  return out;
}

/* ---------- rewards ---------- */
function rewView() {
  var r = rules();
  var bal = hold(h("button", { class: "bal", onclick: function () { toast(t("hold")); } },
    h("span", { text: t("sp_bal") }), h("span", { class: "n", text: S.sp.toLocaleString(S.lang) + " SP" }), h("span", { text: t("hold") })),
    function () { openSheet({ type: "hold-bal" }); });
  function buy(pi) {
    if (!C.testMode) { toast(t("soon")); return; }
    credit(pi * r.spPerPi, "h_buy", pi + " Pi"); save(); render(); toast(t("test_credit"));
  }
  return [
    h("div", { class: "line", style: "justify-content:space-between;align-items:center" }, h("h1", { class: "h1", text: t("sp_title") }),
      h("button", { class: "avatar", "aria-label": t("settings"), onclick: function () { openSheet({ type: "settings" }); } }, ic("gear"))),
    bal,
    h("div", { class: "row2" },
      h("button", { class: "btn", onclick: function () { openSheet({ type: "send" }); }, text: t("send") }),
      h("button", { class: "btn", onclick: function () { openSheet({ type: "receive" }); }, text: t("receive") })),
    h("h2", { class: "h2", text: t("buy") }),
    h("div", { class: "row3" }, C.packs.map(function (pi) {
      return h("button", { class: "pack", onclick: function () { buy(pi); } }, h("b", { text: (pi * r.spPerPi).toLocaleString(S.lang) + " SP" }), h("span", { text: pi + " Pi" }));
    })),
    h("p", { class: "tiny", text: t("buy_note") }),
    h("button", { class: "btn", onclick: function () { toast(t("soon")); } }, ic("play", 18), t("watch")),
    h("h2", { class: "h2", text: t("hist") }),
    S.hist.length ? h("div", { class: "hist" }, S.hist.slice(0, 30).map(function (x) {
      return h("div", {}, h("span", {}, h("b", { style: "font-size:14px", text: t(x.k) + (x.x ? " " + x.x : "") }), h("span", { class: "tiny", style: "display:block", text: when(x.t) })),
        h("span", { class: x.a >= 0 ? "plus" : "minus", text: (x.a >= 0 ? "+ " : "− ") + Math.abs(x.a).toLocaleString(S.lang) + " SP" }));
    })) : h("p", { class: "sub", text: t("no_hist") })
  ];
}

/* ---------- admin ---------- */
var RULE_LABEL = { spPerPi: "SP for 1 Pi", likesPerSp: "Net likes for 1 SP", chatMsgsPerSp: "Chat messages for 1 SP", meetingPeoplePerSp: "Meeting people for 1 SP",
  channelSpPer100: "Channel SP per 100 members", minPosts24h: "Posts needed in 24 hours", groupLimit: "Group member limit", meetingMinutes: "Meeting minutes",
  meetingPeople: "Meeting people limit", chatDeleteDays: "Chat auto-delete days", dailyRewardCap: "Daily reward SP cap", dailyDislikeLimit: "Dislikes per day",
  weeklyClaimLimit: "Claims per week", userCap: "User cap before waiting list", adEveryMinutes: "Minutes between Pi ads", adRewardSp: "SP for a watched ad", adRewardPerDay: "Rewarded ads per day" };
function resetData() {
  var keep = { lang: S.lang, promoSeen: S.promoSeen, user: S.user, rules: S.rules, ticker: S.ticker };
  S = Object.assign(seed(), keep); save(); ui.sheet = null; ui.room = null; render(); toast(t("a_saved"));
}
function adminView() {
  var r = rules(), k = ticker();
  function saveRules(e) {
    e.preventDefault(); var out = {};
    Object.keys(RULE_LABEL).forEach(function (key) { var n = Math.floor(Number(document.getElementById("ru-" + key).value)); if (n > 0 && n !== C.rules[key]) out[key] = n; });
    S.rules = out; save(); render(); toast(t("a_saved"));
  }
  function saveTicker() {
    S.ticker = { bg: document.getElementById("tk-bg").value, fg: document.getElementById("tk-fg").value, speed: Math.min(200, Math.max(15, Math.floor(Number(document.getElementById("tk-sec").value)) || 45)) };
    save(); render(); toast(t("a_saved"));
  }
  function postAd(e) {
    e.preventDefault(); function v(id) { return document.getElementById(id); }
    var a = { id: uid("a"), title: clean(v("ad-title").value, 60), text: clean(v("ad-text").value, 200), link: clean(v("ad-link").value, 120), city: clean(v("ad-city").value, 40),
      from: v("ad-from").value, to: v("ad-to").value, places: { ticker: v("ad-p-ticker").checked, feed: v("ad-p-feed").checked, chats: v("ad-p-chats").checked, meet: v("ad-p-meet").checked } };
    if (!a.title || !(a.places.ticker || a.places.feed || a.places.chats || a.places.meet)) { toast(t("e_req")); return; }
    S.ads.unshift(a); save(); render(); toast(t("a_saved"));
  }
  function fld(id, label, type, max) { return h("div", { class: "field" }, h("label", { for: id, text: label }), h("input", { type: type || "text", id: id, maxlength: max ? String(max) : null, autocomplete: "off" })); }
  function chk(id, label, on) { return h("label", { class: "chk", for: id }, h("input", { type: "checkbox", id: id, checked: on }), label); }
  function decide(c, ok) {
    c.status = ok ? "approved" : "rejected";
    if (ok) { var o = findTarget(c.target); if (o) { o.voided = o.dislikes.length; if (c.target.kind === "post") postReward(o); } }
    save(); render();
  }
  var open = S.claims.filter(function (c) { return c.status === "open"; });
  return [
    h("div", { class: "line", style: "align-items:center;justify-content:space-between" },
      h("div", {}, h("h1", { class: "h1", text: t("admin") }), h("div", { class: "sub", text: "@" + C.adminUsername })),
      h("span", { class: "tag live", text: C.testMode ? "TEST MODE" : "LIVE" })),
    h("p", { class: "note info", text: t("a_note") }),
    h("form", { class: "card", onsubmit: saveRules }, h("h2", { class: "h2", text: t("a_rules") }),
      Object.keys(RULE_LABEL).map(function (key) {
        return h("div", { class: "rule" }, h("label", { for: "ru-" + key, text: RULE_LABEL[key] }), h("input", { type: "number", id: "ru-" + key, min: "1", step: "1", value: r[key] }));
      }), h("button", { class: "btn pri", type: "submit", text: t("save") })),
    h("div", { class: "card" }, h("h2", { class: "h2", text: t("a_colors") }),
      h("div", { class: "rule" }, h("label", { for: "tk-bg", text: t("a_bg") }), h("input", { type: "color", id: "tk-bg", value: k.bg })),
      h("div", { class: "rule" }, h("label", { for: "tk-fg", text: t("a_fg") }), h("input", { type: "color", id: "tk-fg", value: k.fg })),
      h("div", { class: "rule" }, h("label", { for: "tk-sec", text: "Speed (15 slow \u2013 200 fast)" }), h("input", { type: "number", id: "tk-sec", min: "15", max: "200", step: "5", value: k.speed || 45 })),
      h("button", { class: "btn pri", onclick: saveTicker, text: t("save") })),
    h("form", { class: "card", onsubmit: postAd }, h("h2", { class: "h2", text: t("a_ads") }),
      fld("ad-title", t("a_title"), "text", 60), fld("ad-text", t("a_text"), "text", 200), fld("ad-link", t("a_link"), "text", 120), fld("ad-city", t("a_city"), "text", 40),
      h("div", { class: "row2" }, fld("ad-from", t("a_from"), "date"), fld("ad-to", t("a_to"), "date")),
      h("span", { class: "lbl", text: t("a_places") }),
      h("div", { class: "row2" }, chk("ad-p-ticker", t("a_ticker"), false), chk("ad-p-feed", t("a_feed"), false), chk("ad-p-chats", t("a_chats"), false), chk("ad-p-meet", t("a_meet"), false)),
      h("button", { class: "btn pri", type: "submit", text: t("a_post") })),
    h("h2", { class: "h2", text: t("a_live") + " (" + S.ads.length + ")" }),
    S.ads.length ? S.ads.map(function (a) {
      return h("div", { class: "item" }, h("span", { class: "grow" }, h("b", { text: a.title }),
        h("span", { class: "sub", text: Object.keys(a.places).filter(function (p) { return a.places[p]; }).join(", ") + (a.city ? " · " + a.city : "") + (a.to ? " · → " + a.to : "") })),
        h("button", { class: "btn danger sm", "aria-label": t("del") + ": " + a.title, onclick: function () { S.ads = S.ads.filter(function (x) { return x.id !== a.id; }); save(); render(); } }, ic("trash", 18)));
    }) : h("p", { class: "sub", text: t("empty") }),
    h("h2", { class: "h2", text: t("a_claims") + " (" + open.length + ")" }),
    open.length ? open.map(function (c) {
      var o = findTarget(c.target);
      return h("div", { class: "card" }, h("b", { text: "@" + c.by + " · " + c.target.kind }), h("p", { class: "txt", text: c.text }),
        o ? h("p", { class: "sub", text: (o.text || o.name || "") + "  (+" + o.likes.length + " / -" + o.dislikes.length + ": " + o.dislikes.map(function (d) { return "@" + d; }).join(", ") + ")" }) : null,
        h("div", { class: "row2" }, h("button", { class: "btn pri sm", onclick: function () { decide(c, true); }, text: t("a_ok") }), h("button", { class: "btn flat sm", onclick: function () { decide(c, false); }, text: t("a_no") })));
    }) : h("p", { class: "sub", text: t("empty") }),
    h("button", { class: "btn danger", onclick: function () { openSheet({ type: "reset" }); }, text: t("a_reset") })
  ];
}

/* ---------- render ---------- */
var hosts = null;
function render() {
  if (!hosts) {
    hosts = { top: h("div", { class: "host" }), tick: h("div", { class: "host" }), body: h("div", { class: "host" }), sheet: h("div", { class: "host" }) };
    root.replaceChildren(hosts.top, hosts.tick, hosts.body, hosts.sheet);
  }
  var old = hosts.body.querySelector(".main"), top = old && ui.keep === ui.tab + "|" + ui.room + "|" + ui.admin ? old.scrollTop : 0;
  var head = null, kids, showTick = false;
  if (ui.view === "promo") kids = [promoView()];
  else if (ui.view === "signin") { head = header(); kids = [signinView(), footer(false)]; }
  else if (ui.view === "profile") kids = [profileView()];
  else {
    var room = ui.room ? S.rooms.filter(function (r) { return r.id === ui.room; })[0] : null, body;
    if (ui.admin && isAdmin()) body = adminView();
    else if (ui.tab === "chats") body = room ? roomView(room) : chatsView();
    else if (ui.tab === "meet") body = meetView();
    else if (ui.tab === "feed") body = feedView();
    else body = rewView();
    head = header(); showTick = true;
    kids = [h("main", { class: "main" }, body), nav(), footer(false)];
  }
  if (head) hosts.top.replaceChildren(head); else hosts.top.replaceChildren();
  hosts.body.replaceChildren.apply(hosts.body, kids);
  if (ui.sheet) hosts.sheet.replaceChildren(sheetView()); else hosts.sheet.replaceChildren();
  updateTicker(showTick);
  ui.keep = ui.tab + "|" + ui.room + "|" + ui.admin;
  var now = hosts.body.querySelector(".main"); if (now && top) now.scrollTop = top;
}

/* ---------- start ---------- */
load();
if (!S.lang) { var nl = (navigator.language || "en").slice(0, 2).toLowerCase(); S.lang = L[nl] ? nl : "en"; }
document.documentElement.lang = S.lang;
(function prune() {
  var cut = Date.now() - rules().chatDeleteDays * 864e5;
  S.rooms.forEach(function (r) { r.msgs = r.msgs.filter(function (m) { return m.ts > cut; }); });
})();
save();
render();
})();
