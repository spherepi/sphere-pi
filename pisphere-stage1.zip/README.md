# PiSphere ऐप: चरण 1

यह PiSphere का पहला चरण है। ऐप पूरा चलता है, पर सारा डाटा अभी सिर्फ उसी फोन में सेव होता है।
सर्वर, असली Pi पेमेंट और वीडियो मीटिंग चरण 2 में जुड़ेंगे।

## फोल्डर में क्या है

- `index.html`: ऐप का मुख्य पेज
- `css/app.css`: डार्क थीम और सारे रंग
- `js/config.js`: सारे नियम (1 Pi = 1000 SP, रिवॉर्ड, लिमिट, एडमिन यूजरनेम)
- `js/i18n.js`: 11 भाषाओं के शब्द
- `js/app.js`: ऐप का लॉजिक
- `assets/`: लोगो और प्रोमो वीडियो
- `_headers`: Cloudflare Pages के लिए सिक्योरिटी हेडर (अभी Cloudflare पर टेस्ट नहीं हुआ)

## चरण 1 में क्या चलता है

- प्रोमो वीडियो, फिर Pi साइन-इन (टेस्ट मोड में यूजरनेम लिखकर), फिर प्रोफाइल फॉर्म
- चैट, ग्रुप, चैनल, पोस्ट फीड, मीटिंग ग्रुप की सूची, Rewards (SP)
- नाम छूने पर प्रोफाइल कार्ड, दबाकर रखने पर Like, Dislike, Tip, Pin, Unpin, Delete
- डिसलाइक पर क्लेम, और एडमिन पैनल में मंजूर या खारिज
- एडमिन पैनल (यूजरनेम RK33): नियम, टिकर के रंग, लोकल विज्ञापन, रीसेट

## चरण 2 में क्या जुड़ेगा

- Supabase: सबका साझा डाटा, असली चैट, सर्वर पर SP का हिसाब
- Pi पेमेंट: SP की असली खरीद, और सर्वर पर Pi यूजरनेम की जांच
- LiveKit: असली वीडियो मीटिंग
- Pi Ad Network: मंजूरी मिलने के बाद

## अकाउंट बनाने के लिंक

- GitHub: https://github.com
- Cloudflare Pages: https://pages.cloudflare.com
- Supabase: https://supabase.com
- LiveKit: https://livekit.com
- Pi डेवलपर पोर्टल: Pi Browser में `develop.pi` खोलें

## Cloudflare Pages पर डालना

1. यह पूरा फोल्डर GitHub की एक प्राइवेट रिपॉजिटरी में अपलोड करें।
2. Cloudflare Pages में "Connect to Git" से वह रिपॉजिटरी चुनें।
3. Build command खाली छोड़ें, output folder `/` रखें।

सीक्रेट की (Pi API key, Supabase service key, LiveKit secret) कभी इस फोल्डर में न डालें।
